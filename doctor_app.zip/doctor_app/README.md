{
  "doctor": [
    {
      "id": 1,
      "docName": "Karthika Thiyagarajan",
      "docMailId": "karthika@gmail.com",
      "rating": "4",
      "qualification": "MBBS,MD",
      "specialization": "Phsycologist",
      "overallExperience": "9",
      "consultationFees": 500,
      "location": "Chennai",
      "profilePhoto": "https://th.bing.com/th/id/OIP.leRzD8YnH9F3wHyXPDFpyQAAAA?pid=ImgDet&rs=1",
      "detailedDesc": "Dr. P.karthika is a gynacologist in chennai City, chennai and has an experience of 9 years in this field. she practices at E.B.K Medicals in chennai City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur"
    },
    {
      "id": 2,
      "docName": "Thiyagarajan",
      "docMailId": "Thiyagarajan@gmail.com",
      "rating": "3",
      "qualification": "MBBS,MD",
      "specialization": "Phsycologist",
      "overallExperience": "9",
      "consultationFees": 500,
      "location": "Chennai",
      "profilePhoto": "https://th.bing.com/th/id/OIP.YiGJ1gcqIG1IA36y0YmXYQHaLH?pid=ImgDet&rs=1",
      "detailedDesc": "Meena Thiyagarajan is a gynacologist in chennai City, chennai and has an experience of 9 years in this field. Dr. P.Meena Thiyagarajan practices at E.B.K Medicals in Thanjavur City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur"
    },
    {
      "id": 3,
      "docName": "Kingsley",
      "docMailId": "Kingsley@gmail.com",
      "detailedDesc": "Kingsley is a gynacologist in chennai City, chennai and has an experience of 9 years in this field. Dr. P.Ezhilan practices at E.B.K Medicals in Thanjavur City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur",
      "rating": "5",
      "qualification": "MBBS",
      "specialization": "General Physician",
      "overallExperience": "19",
      "consultationFees": 700,
      "location": "Chennai",
      "profilePhoto": "https://th.bing.com/th/id/OIP.8PswX9NrZdkwRgyTAtuzhgAAAA?pid=ImgDet&rs=1"
    },
    {
      "id": 4,
      "docName": "Bhuvanesvari",
      "docMailId": "Bhuvanesvari@gmail.com",
      "detailedDesc": "Dr. P.Bhuvanesvari is a gynacologist in chennai City, chennai and has an experience of 9 years in this field. Dr. P.Bhuvanesvari practices at E.B.K Medicals in Chennai City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur",
      "rating": "5",
      "qualification": "BDS",
      "specialization": "Dentist",
      "overallExperience": "11",
      "consultationFees": 800,
      "location": "Chennai",
      "profilePhoto": "https://imagesx.practo.com/providers/c1631e6f-a0e6-4bd8-8f89-7d1e60b086de.jpg?i_type=t_100x100-2x"
    },
    {
      "id": 5,
      "docName": "Sanjana",
      "docMailId": "Sanjana@gmail.com",
      "detailedDesc": "Sanjana is a dentist in chennai City, chennai and has an experience of 9 years in this field. Dr. P.Ezhilan practices at E.B.K Medicals in Thanjavur City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur",
      "rating": "5",
      "qualification": "MBBS",
      "specialization": "Gynaecology",
      "overallExperience": "19",
      "consultationFees": 900,
      "location": "Chennai",
      "profilePhoto": "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAsJCQcJCQcJCQkJCwkJCQkJCQsJCwsMCwsLDA0QDBEODQ4MEhkSJRodJR0ZHxwpKRYlNzU2GioyPi0pMBk7IRP/2wBDAQcICAsJCxULCxUsHRkdLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCwsLCz/wAARCAEOAVoDASIAAhEBAxEB/8QAHAAAAQUBAQEAAAAAAAAAAAAAAQACAwQGBQcI/8QAQxAAAgEDAgQEBAUDAwIFAQkAAQIRAAMhBBIFEzFBIlFhcQYygZEjQlKhsRTB4WJy0TPwBxUkQ6JEU2NzgoOSs8Lx/8QAGgEBAAMBAQEAAAAAAAAAAAAAAAEDBAIFBv/EACkRAQACAgICAQMFAQADAAAAAAABAgMRBCESMUEFEyIyUWFxoUIjgcH/2gAMAwEAAhEDEQA/APW6qEkE+5pEkE5P3q0AIGB0HagSztX/AGj+KrOx3vnuaTE7myep86sIBsXA6d6AWySi+39zUV1iHInsKFwkOwBgTgCpbQGxZg9etArUlPqaZeMMM9qF0w+MYHSn2gCpJznvmgVkkh58x/FC8SNsHzoXsFYxjtijZzvnMR1zQKySS0+Qp12Qojzpt4QEjGT0xQsyWM5x3zQCySX69jUt2Qh9xTboAWQIyOmKZaMuO/XqaAWyS6586ncwje1C4BsaBHtUKE71BJgnz/tQBGO5M9xVk9D7GgwG1sDoaqNcW0puOTtQSfX0E4pPXZEb6E3Ao3M0AZ8/sBXG4h8S2LD3LVi7p1dcQ7q7z/tU4qrxHV3ddu33NmmE7bVlgqtEiHuL4j6gYrKazUPpt62NPatoTPgtOSc9TuIrFlzTE6q24sG+7OpqOM63VsXe/YCiYMrtGegiua3GLttwovW3zG7KN9NwiuHf4hqmZt5IHpaX/mqD6gMYYiI/Nbj7bGqmJtM+18xWOmts8U1F7UWkvPA3l1ICql1T4drR0rQWPi29pr39PqVR7dsKCwAVgBAgnz+hrzvR3XQkW2DofmTduAH1yKuaouXt6hW8F0BHEwwcCAD3irIvas+1c0rMPXrGt0+ttjUaa6HtmASDlWidrDzq7aPgHua8h4NxPWcP1K3bTAZ23AGLIV7h1NenaTW2tdZS9b8JgB0B+ViP4rTTJFup9smTFNFy8SGGe1OsmVafOlZgr0BgkZzTb2CoGBBmDFXKhvEjZ9aNkyWz2FCzkNOenXNK9jZGJnpigN4kBfem2SSxzPhP8ilayWnOO+addwojGR0xQG6YT6iorRJdc+f8UbWXE5wcEzUt0AI0ADp0x3oDc+RvaoEJLJn8wpJJZZOJ86ncDa+BgEjFATMH2NVQzYz3HWkpkqJOSO9WiBBwO/agNVCzZz3NCSIyfvVsAQMDt2oCJgewqqxO9vc/zQJIJyep71ZUDapgdPKgVudie1Pqq58bDyOM02T5/vQWtq/pX7VWLOCfEevnSZ7knxGpwiEDwjImgKhdoJAkgHIqBmYMwBIAJgAmKTO4LAMQASAJ8qlVEZVJUEkSSepoCiqUUkAkjJOaiuEhiASBAwDQdmVmVSQB0A7VKgV1BYAk9z1oBaAZZYAmTk5pt2VYBTGOgwKVwlGhTAiYFOtgOJYSZiTQC0Nwbd4ukTmMUrvh27cTMxihcJQqF8IIzHeja8e7f4oiJ7UCteLduzAETn+aN0bVBXBnqMGhcGzaU8JMgx3oWyXYhsgCYNArcs0MZEHByKfcACyAAZGQINC4AiyggyBIpttmZgGMiDg0DbZYsoJJBmQTUzqoViAAQMEdqDqqqWUAEdCOtRIzFgCSQTBB70AVnLKJJkjuaw3HuL6ri/Er3COG7zo9CH/qn0w3G/dETMflXoB3MnoK13G9YOHcO1OotoDeYDT6cDH413wAkjsMk+1ZjhnDdNZspYW0qeMXGKu1t3uH89zZn2E1TktrpfirvtXt6ezobcq6NcKTvuh3ZRHyhkkD1gVnte2rv3DLFhMCGc4+q16IOD6O4VL2ziCfERJ+lNucM0KyBaUfTP3rDkm096baTV5Pd0upEytzz8Of7VXKPGUux5kKR/zXqd3h+jk/hr9hVN+HaLP4a57R2qj78x8LYxxPy83WySQyEbgZGCjCO4NdWzYu6vT3LNwnmBS1tyJbcBIBI6itLd4Po36KAQZBHahZ4bcsNgyCDtqfv7dTh0xVi7csXFJZlIaD3kg5kHFeicA1ptrZvCAqkLfTr4W6EelZLWaUWdRc32g6uxlMrOZhW7HyNd/gjWraQhL2btsPbLCG2g7XtuOzKev7YNXRfephRemo1L0F3+QofCyhhBwZ9qktDcCWE5757VS4XcW7YKNDG1AUnPgPSrdzwbQuARJivSpbyjbzLRqZgbvh27fDMzGKVrxFt2YAicxSteMNv8URE0rng27PDMzHeK6QV2FC7YGe2KbalmIYyNswcijbJckP4gBImnXAEUFRBmJHlQG4AqEgQcZGDUdsszAEkgzIJJ7UrZLsFYyIJg9MVI6qqFlABEQR1oE6gIxAAIyCBkVEjMWUFiQWzJkUkZmZVYkgmCD0qV1UKxAAIEgjsaBxVQCQBgHtVbe8jxHMd6cHckAsYJE1Pst58K96BbU/SPtVbc+fEfuaW+513GrIS3A8K0CCrA8I6eVQMzBiAxABMCaBdwSAxgEgVOqIVUlRJGaBIAVUkAkjJImnbV/Sv2quzMrMFJABwBQ33P1H70E/Ltn8o/eoS9wEwxgYAxRN24Ccj7CpBatmDHXJz3oELaEAlRJEnr1NRs7qzBTABgCkbjgkA4BI6DtUgtowDN1Ik5NAlVWAYgEkSSe/amOzIxVTAAGKDM6MyqYUdMf3p6orqGbJM5mgSAOu5oJkifT6U1ybZhDAInH+aTs1tiqGBAPn/NFVFwbnyQYEY/igSAXAS+SCInyie1K5+HGzEzMf5oOTbICGNwkzn+aKRd3b87Y6YoBbm4SHzGR/2Kc4CCUEEmD/ANmg4FvaUwTgznH1oITcJV8gCcYoFbLOYcyInPpT3VUXcsAyBPv701lFsbkwZA88fWgrNcYK5kGaAKzOwVjKmZGKkKIqkgAECR/2aDIqKWXqOmTTFd3KqTKnrig4HxEb908HtKZIv37+3G3ciC2rNPZdxNN4Np7bTcFxrignx4IuNOWn/ND4pfRacaV77A7rb20skkl4cMSR5ec9a63DrBtaWwWwzojkfp3CQBWXJG7NVJ1VaYhVgCqN4kk1eZGaYFUb0DrHcVTl6hZj0oXG/eqbmSatXmGfY1RMma86e2+hs5qVCCQPWoDM5pyyIg1xC2YQcV4el1Nwjoc9weoNc/hb7BqQwO6yxuOnntG26B7iGHt6Vp0Tn22BEwue9cQ6dtNrHdEliu4D9YXJH9q0U6n+Ga3calouDXHU37e4yAM46AyD9jiu6g3gl4YgwJ/xWb4HyX1S8skodM6ZPW2rBrZMdwDH0rROTbICGARJnOelerg/S8vL+oX/AAyuzE9QPT3pW/xCQ+doET/ikg5gO/MREY/ik/4cFMbpnv8AzV6obg2AFMEmDH+aahLna5kQTnz+lJCbhIfIAkds/SiwFsBkwZAznFAXVUXcoAM9vWmIzOwVjKmZH/8AlFWNwhXMrk+WacyIillwR5mf5oCyqillABHQ561GruxAJkEwemaSuzsFYgg9aebaKGYCCBIz3oHG2gBIAkSR1qHmXMS3WPLvSFy4xAJwTB6VNy7YkwcT3NAjbt/pFQ8y5mG746UuZc/V+1S8q15H7mgIt2yAYGfeoWd1JAaACQB6UjduAkA4BIGB0FSi2jAE9SJOY/igSqjKrMBJEnrTuXb/AEj96hLuhKqfCDA6dKXNuef7CgkNlCe/3qM3XEjGMdM0TefOFp3KQ5JOc/egQtIwDGZYSc+dNNxlJURAwJpG66yoAhTA9hincoN4iTJyY6UCCK4DN1bJg4prM1s7ViB5+tI3GtnYAIXAnqe9EILgDtIJ7D0oCqi4NzdemMdKDE2yFWIOTOaBY2jtWCInPrRA5o3MYIxigSgXZLdVwIx60m/Cjb3GZz0oMTZwuQRJ3dfLtRWb3zfl6bfWgSnmkh+gEiMUmAtAFepMZzQYGzBX82Du9KSk3fC0QM+GgSsbh2tEROMZFOZVtjcvUYznrQKi0NymT0z60AzXTtaIycdcUAV2chGiD1jrTyioCw6qJEmgUFsbwTK9AemaAuM5CGIbBjrQcDjapq3GndBvtNprlq4ozsuSGSfcV3bghI3bBtAkdRjtVfVcpb+js7QTeZiWP+gTFLWF2Tapg9j5Gsflry+WqK78XA4sthtyjXa2wSD4rd/bn2OJrgHXfEeiKrb1FviWlBwt2FvgeQPQn6/SpuI8K1wvm5rL1uzpXS4TqdLZOq1C3OqW250hVPmqH6daxVj/AMwt6m839RcQIhcNcxzWBnZAxn2rN42tu0y3RatdViNt/ouIjXLcDWbtm4g8aXQR9iQKmBiZqrwS7c1llN4y9vcDn++an1QNrcZgKCTWK24aOt6Vr/EtBpi3PvopU5X5m+wqG38Q8GZtq/1L95t2GYVwdZrNLbe69vRc64N1xiQTtEgFjNQaT4gvm4FbTqttWVXYBltoSYG98qPrFXVxTMbiHN8lYnUy9K4RqtBqD+DcB3Lu2uCjj0Iaq/HdmiucP1QgJc1KWH/SGYGD9YioOD8RsPy96QxYDa4G5T6Ef811ePacX9AloIHJ1Ftl3CQCAYMVopFbU1+zJfdbqXw4jpqOJmBs07mxaPmlwi8I9hFadRzct1XAjHrXP4OFu6Odhtqt65bQd2CHbuM586vkm1AXIbJmt2GNUhhy/rmBabUBfzdZz0pJ+LO/8sER60l/Fndjb0296R/Cjbndg7vSrlRMBaAKdSYzmgjG6drRETjGaIJu4bAGcdaRUWhuUyZ256UBZRbG5esxkz1pqu1whGiD1j0zSDNdOxsDrjriiUFsF1JJHSemcUBKKgLDquRJpouOxCmIJgx1pC4znYdsHBinG0qAsCZXImO1AeUgEiZGR9Kj5rn9OTHSjzXMAgQcY9adyU8zj2oDyU9fvUfNcfp+1LnP5LT+Sp7tmgItIYJnOevnUZuOpKiIBgTR5riQAMYGKdylaGJIJyfrQIW1cBmmWyc0eTb9fvTDcZCUEQpgT1pc5/JftQO5KkzuOfam85hjaMY70TeIPy/vS5M53dRPTzoDyg3iJPiziO+abzSkqADtxJNHm7fDtnbiZ6xS5e/xTG7MRNAhbFyHJILZgf5oFzbOwAGO+e9HeU8ETGJmJ70thu+OYntQILzfGcHpA9PekSbXhEGc5/xS3G14InvMx1pbed4jiMR1oEBzpJ8O3GPv3pH8Hp4t3n6e1KTZx827PlFIfjeS7fr1oECb2DjbnH+aRHK8QzOIP+KUGzn5t2PKIpTzvDG2Mz1oAGN3wmAOuPSnFBbG8GSMR747UNnK8XXtHTr3pb+b4IiczM9KABzcIQgAN3E+9HlhPECSVyJj+1Llm3+JM7e0RNIXC/g2xuxM0EbkXChKpuRgyMcxmDFQXWlo8jFWza2jdMxmI61TuRzSYgQDWbNGu4aME/Eufr03Lt7GuAeEWLlwGPFPoP4rv6y6Jjy9a5Z1aW3HnIrzLzHk9XHE+PTp6Lh9rToCAJgD6VztXZa++oQDNaHT506uSPEgYexE965dsg6nUAZw2B3jyqy9I1EfuqpaZmZYnVcK2vcOxTvG1pmSo7H2puj4RoEZg9u4bVwqbtkXCLVzbmHUdRWg1jg6q5bK7TgwR2IwaSW7eDtE1R52r1EtXjFo3MH6LQaWzctHT2Es2+YGCW52gz2kmtJxK89rT6com+61+zbQQYEsNxMdgJmqemtK1pDGQREUuL37jp/Q6TcdZqALRCEbktAguR2E9KvrutJmfnTJk1No/h2rT27du3ydrW3XepU4IbMiKkA5viOIwAP81R4XptTb02y8AmxgEWQxjaJOMCTNXp5WPmnPl6V6mOZmkTMaeVeNWkj+DAHi3efp7UhN7rjbnHr70oN6D8u369aUGzn5t2PKIqxyRHJyMzjP+KAbm+E4/NI/zRnnYiIz50tvJ8XWcR0oEV5XjBk9IPrQDm5CEQD3HXGe9HfzfBETmevSly+X4wZjt0mcUCNsWwXBJK5gxmgLjN4YADGMdf3o8wv4NsbsTNLlbPFM7fFEdYoDyguZJjMGO1N5zdNozjv3o80nG2JxM+dLkxnd+1AeSv6j+1N5zD8ox6mjzj+n96XJn83X0oDygc7jnPamm6V8MDBjv2o86MbemOvlS5O7xT82enSgQth4eYLZIEUeSP1H7ChzCngiduJmKXOP6f3oEbJJ+b9qPOAxtOMdfKlzlBjace1N5LnMrnNAeUWlpjdmI86XMCeErJXE0eaqiCDK4P0ppts5LAgBsgGgPLLnfIG7MeXakH5fgImO4oi4LYCMCSvWOlNKNcO8EAHzntigJXm+MYHTPpSDcnwkTOcYpBhaG1gSeuOmaBU3fEuAMQf8UBjnZGNuM59aQ/B6+Ld5elIHlSGk7sjb6Y70jN2NuNvWfWgRIvYAjbn70o5PiOZxAxSUG1JbO7AikTzfCuCM58vpQLdzfCBHeTnpS2G14yZAxA9aCqbXiMEdIHmfenFxcGxQQTnPpmgBfmeDaQW7mgLZTxSDtzA70gjWyHJEDrE+1ONwONoBlsCelAOaG8O2N2JnzqprF5YUz2g1aFp1hiRAz3qLUhbqEAHp3+9U543SVuGdWhl9bf2lhkt2jrXPs2DeffcB2xAE11uIadAruPmOT2M1zLFzi1ncRp9LesFoALPbu2/UmSpBrwu5vp7tJ3Xpdu3tWp023UslnTjxJtQi6o6ByROPSqFziBVmbT/9Q3AdzDoo7AT3qnrOM6xXey+lt2vCcspZIHbfPX6VyjxO4W8CWwBJ8FtiTHuavml4X14863MOzeu3b95tS5BuNtkLO0KogKCatWWW5GSD3B6zXLtazV3EW2eHuVYKWvMVsqk9thkk+ddXRWCxNwzCASPOqLRNbalxb8fbR6AKtsM+EtK11z5Kg3Gq/wANPb1un1OrAUXb19rm6JY2rpNxYPWJJqnx7Vvw34Z4lcDFNTrEXQaaPm5mpOyF9l3H6VJ8IodJpnsuQxS3bQ7TMbQD1+prdWfG+N5WTdq3lpwwteEiT1xiKUc2CMRjOaRU3TuXAGM0geV4WyTnFeq84h+Dg+It5Y6Uv+tAA27c5zM0j+LG3G3ru9fakv4XzZ3YG3096BRyTJzuxA+9ItzvABEZk5pEi7AURGc/4oKvK8TZHy49fegITleM5jEdOtIvzBsAgnue0ZpFuYNigg9ZPpQCNbIc5A6gdc4oDyynjkHbmKRuB/DBG7Ez0mibiuCgBBbAJpotsp3EiFMmJmKA8kjMzGenlR5yn8pzjr50uarYCmTgT60zkuIMiB79qA8g/qH2p3OA/KcetLnJ5NTeS/mM+9AuSTmesnp507mhfDtMrjr1pc1Rgg4welNNpmO6RkyJ9aA8sv45jdmKXIP6h9qIcIApBJXBjpR5q/pb9qBhsvJ6fenc1BgzjHTyp3NtzEn7GoTauEkgdcjP1oCbTsSwiCZEnsakFxVG0zIwY6UhcRQFMyoAOD2FRsjsSwGDkZoCbbOS4iGyJwacHW2AjTIzj1oq6oArTKjODTGVrjFlGD5nyoEym4dy9IjOOlFSLQ2t1OcUVZbY2vg5OM9famuDcO5MgCDOM/WgLDmkFegEGcUl/Cnd+bpGelJCLYIfBbpGfTtSf8WNmY6zjr70CYi7AX8uTOKSg2jubocCM0kBtEl8AiBGf4pORcACdQZzjFAmYXRtUGeufKgqm2dzRGRjPWkgNs7nwIjGcn2pzMtwbVOeuZFAi6uNizJ6SMYpotshDmIXJjrQVGQhmGB1yKkLo4KiZYQJBFAjdRgVAMkECfWo+S/ciKQtupDEYGTkdKlDo+BMn0NRPY42rsBpBypmDVJbJRcDAkH1HkalXi2k4i3E00kzw2/b0zlo8TNbFyaamrs3AyGFuDO1uje1eJmitcsx8vVxTPgzvEdM3MLpIBOZyv71z7GhTmK1wsYPyiFX6kZrSaprTTI6VQC2iwx1PbvVU3v+7065reOky2nugALCqIWOldHQ6YoURgIkHPnQ5+j0WnW5eYDcCEQZd4/StRafX3LtvWakJtXT6XU37duZ8Vu0zLuJ61FYiJjynuWO02mJlnOOax+N8Rs21Y29BwxnGms3AUu39Q2G1FxDkDsgPb/dWh+F55ty0rFiUdiScYjMHNU9BptL8YcI0fFtOqWeKWANLeLyEvhIlLpWWgdVP0rT8H4VZ4QlzmXGvam7HMuEdEHy219BW+OPecsWn1DHbNWMc1j26isLQ2tMzOM4oMObBTtjOKDA3DuQSOmcZ+tFCLWHwSZEZ9O1em88l/Cnd1bIik34sbPy9Zx1pP8AiRszHWcdfekn4U78TERnp7UAUG0ZbocYyaLMLo2rIMznypORcACZIMmcY+tBFNsln6RGM5oEqtbO9ojpjrmnM63AUWdx6T6ZpMy3BtTJmYOOnvTVVrZDMPCJmM9cUAFtkO8xA6waebisComWwJxSLpcUqpycCQRTBbdSGIEKZMHtQIWnEExAzg+VP51s9mz6UeZbIgEycDB71Fyrg7DrPWgPJf0P1qTnIPPHpR5tvzP2qHlXD2H3FAeU5kiM5GaeLiKApmRg/SiLtsQDMjBwajNt2JIGCZEmgJts5LCIYyJNLlP6fenh0QKrSCuDg0ubb8z9jQRG3cJPh/iphctiBPTH1o8y2PzD71XKOSYUwZINASjksQpgknt3qVXRQFYwQIIoq6AAFgCAAZ9KhZGLMQpIJkEd6AsruxZRKnofOnoyooVjBHaijKqqGIDAZB6jvUbqzMWUEggZFAnU3GLIJEAT6/WnoRbXa+CTIpWyEWHO0yTB8qbcBcgoNwiJFAnBuFSgmBntRt/h7i8CYilbIQHd4SSIn2ilc/E27PFEzHagTkXNoTJBJNBAbZJYQCIpW/ATu8MgRNOuEOAF8RBmB5UCch12pkyCRTEVkYMwgZzRtgo0uIERJ9ae5DrtUgmQYHlNAHZXUqpknoPOmKjqVZhCjqZpIpVlLAgCZJqRmVlIUgkjFAjcRgVDAkggCgqFVMfMQc+RjFcrS67+u176fSEHS6MbtVf6826ZC2rfp1JPpXZnpXV6TSdWcUvF+4eYfDl7+l4v8RaO43h1y6TiVgnG5WthJA+h+1dbWRbeR51wuO3P6d7uvXYms4FxU8JbaNpuaG9uuWuYOnXI9KuJxC1rtPbuKclQWHcHyrwvqeC1M02+Je3wrxehmp1N0E7XMHqDkVRGs1IceMDP5VFSud0g/wDYqubY3VipaYh6OoSvde8+5mZjiSxk/vU2s4lb0PDdYisA96y9vr0UjJNUrji0pPcSZ9qq6HRXOL67Tf1Erw5bu68zSDeFvxG1bnzxPpVvH49uRkiKqs+SuLH5Wa//AMOrVzS6K/prgKu1uxqmXHga9vYIR5gRNbW8sDfIAAE7iAB9TWf+HbQt6/jbSpJbSI+wyocWyY+xE1pLi22R1uKGRwUdWgqysIIIPavpslYpbxfNeXl2ZbYICGMEmYIoPNwgoJAEGsbw/ieq4Vxe/wAC17Pc0huleGXrhl0tt4rSMx6qRgeRFbKy6gEE9TiusuK2PW/U+nNLxb+4G3+Hu34mIpP+Jt2ZiZpXAW2FcxPSlb8BbfiQImqnYWwbZJcQCIpzkXAAuTIMUrhDhdviIMmM022ChlxtERJoEilGDMIUA5p7srqVUgkxj60HKsu1SCSegpiKysGYEATJPtQJUZWVmEAGScVIXRgygySCAPOkzIysoIJPQVEFZWUlSADJJ6CgQtupBKwAZPTpU3Mt5E9ZpF0II3AyCMHNQbLmPCcRQLl3MEL+9T823+oUt9v9Q+9Qcu5nwnqaAm3cJJ24Jnt0qUOigAmCBmiHtgDxDAqFlcsSFJBJII8qAsjMxZRIJkERmhyrn6T9xUqsgVQSAQIIPanb7f6h+9BXKvJ8J+xqwGSB4hgZzTpHmPvVQgy2D18vWgcVYliFJBJIqZCoVQSAQIIJoqRtXPYd6rvO58HqegmgLhi7EAkE4IqW2QqAMQCOx60bZGxRMGPaobg8bECcDpmgdcBZpUSIGRTrUKpDYMznFG0QFg4MnBqO9lhAkR2yKB13xFduYBmMxSteHdu8MxE4mjZwGnHTrjtQvZ2xJ69M0Cu+ILt8USTGaFrwsS2BHU4FGzgtM5A64qRlDRPYzQNueJYXJkHFNt22Vgx9cVKAAIAgU1mCj1mgJgyCJFcH4m4idFoVsWSRe1hNsbMMLY+aPfA+tduZELWT16DX/EnD9G/iSxZV7g6ic3CD+1a+JWPueVvVe2fkTPjFY+enZ+H+HHh3DrK3M6jUH+q1J/8AvLgEKPRRAHtXXpAQABEAQPal5Vmveclptb3K6tYrEVhj+L8K0+u1PxNw2EF7i+k0fELDnrztOvIU/QgT/urzXh97UaO/c019WR7bm3cRpBV1MGvS/ja/qOGWeF8X04lrF69oNQI+bT6tJyfQqI96yHGbOi4l/TcT4aWbZatW9UQkD5fDnuwzNOTx/vYJvHuF/Fzfay+M+pI3ZIM9aeg3EECqaBgFDdYE10rCSsgfSvlZ6fT660qvZVyXuCbZJVUidxHVmUdh2q42vs2LYIVQNwuIPy23VYJHb2FR6kPZFuNv/TAwJY9SZrn3rFy8rNcMKAfCohY2zX3v03i0w8esxHcxEy+O5ue2XNMWnqG3+BQ1zhd3WPltbxDWXix7hCLQ/itXdOI7d65Pw3pP6PgfA7JEFdHacj/VcHMP81S+I+NanR3LGg0JVddqdzG66hxprCrJcL3Y9BWOaWz5prUm0UpuVD4y0n/pdLrkQrd015IcCDBO4Z9x+9dvhmqfUaTS3yQRds23xkAkSRWMufDvxfr1a9f1gUuNwtam9cuuZ/VHhFR6bVfE/AIF62t3SI0Oglra5iJww/ivRnDTJhjDW8TaP/rNF7RfzmvUvSA7CnhwwAYTXJ4ZxPS8TsJfskicOjRvtuOqtH7V0RXk2pak+No7htrMWjcLKBASV7iDJo3QSoAEmZx5VCnX1in8xl2nqOh8640kLYKsCwgQRJqRyCjAEEmIA60n8aeHMmajQFXEyOs+VQAgYMpIIAOSe1TOVKsAQSQQIPek5BRoM47GoFBDqYjxCcfzQIK8jwnqO1WNyR8y9+9FiNrZHQ96qwcYPbtQLa/dT9qtBkx4l+9KV8x9xVWDnB6ntQEq5JIUwSYwasKyhVkjAzmipELkdB3qs4JY4PU9qAsGLMQCQTgjvQ2v+k/Y1OhAVQTmO5p8jzH3oKZEk4/arYiFz2FH6VTbq3uf5oCw8TwO57VZSNi+1FPlT/aP4qs/zv7mgVwS7GJz1qe18i9utK2BsX2/uahu/OfYUBugF/oKfaICNPQEn2xNGz8n1NNuxvWekCfvQV01Wl1iLd07h1Eq0AhlbyYHNT2iFDzjpWLsarU8M1t25bM7bj271snw3UViIb1H5T29sVrLOt02tt272nfcjHYwIh7bjJR16gj/ALxQXAd0MR7U+RQwPpTFbczAdqkOkZ8hUN0wPU1KIAO6APMnFV7z2SA26Qe8GD7UiBIhwprKcGJ1fxNxnVfktNdtIfYKn9q0/Mtrp71wZFtGfyA2ietZ74OQtpdRqmXxam/qLxY9w1yMemK24fxw5Lf1DNk7y1j+5aylSpVhaXB+LdKur+HuMW9stbsrqF9DZdbk/YGvK+G3LumYohY27oUMkwrEjBHrXtOus/1Gj11iJ5+l1FmB1O+2y4rxWwrgKCCrpy1I6EMsjNet9PtGpiWXPHrTqPZuW2t8xSOYJE4E94q/pdqbZEyYiq2q1FzUaTS3WI3aZghABkq3c07SMbtxQpylu5dE9JAgD96+a5vCinNilI6mX0PF5U24nnae4g97d29dLsSSTtWQAFULgACmaq2Ldi5IyUt49/DXQTl6ccy86sQUCqP9tc8F9bqtFY7X9Vo7RH+lrgJFfaViK11HqHyszNp3Py9Qtotq1YRRAt27aL7KoArz/wCJjd03xVo9Xk240ToO20HlsP5r0RsdPpWV+JOD6rib6Z9O1q3cttse7cBPLtk7tyqsSQR0kd68fh5a48nlf13/AK25qTamod5CIEDHl6VV1Omt3C4ZAy3FyCAQexBmp9Ol1LNlbpVrot2xdZAQjOFAJUEzFOvA8vcOqn9jWXfc6Wx3HbDcNV+F/EGs0NuRYZsKT2IDrHtNbxQ20GKw+tiz8T6O47qH1OnXYWKglgptwAfatvaLhCQZgAkNGR9K382fLwvPuYhnwRMeUfykQdcU1iQWXzp6OhicSep6feheXCsM157SFq4VIn5Sc1ZYBgV88VRBho7H+as2SYM9zj2qJgNUbbigiINTufC+R0NJ1JVgOp6VXT51H+oTUBL1XHcVZ8/Y0m+VsdjVQdvcUCiYwftVwRAz5UoFUz3oCRk47npVlY2rnsKK9F9hVVvmb3NAXHjb1ND6ftVm38ie1O/76UFQzJ/5q0IhcdhS2r+kfaqpZgWye9AW+Z/9xqwg8C47UlVSqyAcDMdagcsGYAkZ6A0CuGHb3/sKltfIv1ooFKKSATGSahuEhzBI6YFAb2H+gqSz8p96VoBlkicnJ8qZdwwAxjsYoMbxa0bfEtcsdbvMGO1wB/71Fpb2r0VwX7MT4ebaYgLfRT8hPY/pPaurxm0qas3D81yxab3iV/tXIuEkH27UGz02ssa3TW9Tp23I+CDhkcdUcdiO/wDmpUIRWP5mkj2HesFp+IajhV06i0d1u4AuptH5bqjAbyDDsfp0rXaTU2NVorursuzrd8O5zDAjqjDzFdQLN67uRQJ8fiJMdAYgRSvDbb0694k1EBuNhf8ASk/XNHieq0ehs3dZrLotaXTW99xzn0CqO5PYVPoU+O6g6XgfEXmC1s2lPq/ho/DNlrPC9CjCCNNZJ93HM/vWa4rxy9xDh+q1Wp+HrK8G01u6zXOKXxb1RtsAjPZsR1PQZrv8E4hpNfpw9lXtGzZsSoY4tungeOsYIz5Grpyx9n7cR3vaqKf+TzmWjpVXX+pH5ldeviGfuKmUkjxCD5TWZaPlXkfE7A0/GeL2QsAa+6VH+l/xB/NetxXnHxbYFnjj3IganT2b/uVU2if2FbuDbWSY/dTmj8VDT299nU2YHjsPlvy+EkEVV4aWaxcuwTvYopHSEGc+5/arWkYrctnftUqquSJwRmqaWrlndpVYhLVy4gGM77haZ+1b8nHjJmpkn/mJU1zTTHfHHys3bhLEAzH7QtXOBWzd43whIwuoa83tass38xVW1p2YMc9H/mK0nwzotvE3vsD+Fp72z3Yov/NaM9oritpTjjdobJqiKgggjBmnswmhXzb0kSrCqDGBBIoXAiq3MKqhBB3dwfIdaF43UH4cCTkkSQPQHFRLbE7mJZz1ZjJ/egpf0eluX7Ny5ZttcNm7bFx0BcC2yXVAJ8jmupbEAL+pWFQQBesDyt6lv/4xU5O02j65rrezSK2SMev8VK7QvhzDQR/eoj4bhHbcaLGXur7Ee8VAa21ojB9anU7SvpE1VmY85FTkxA9RQXBQf5X9jTd/QjpTwQR51Aqg5XPcVaIEHHnQIUBiFEgGq0tjxHr5moCB9f3q3AxjyobVz4R9qqlmz4j1PegDHxNnue9W1jamOwpBVIEqOgnFVWZgzAExMYoDcPjf3ps+tWUAKqSASetP2r+kUFUu8/M33qcIhAO0ZAJxR5duflFQG5cBMHpgdKAFnBYBiACQM9qnVUZVJUEkSSczSCIVUlQSQCfciomZ1ZgCQAYAoE7MrMASADgDp2qS2qsoZgCTOT1pKiMFZhLESTUbsyMVUwABAoFcJRoUkCAYBinJDKWYSQYk5oooddzCTJEn0ptwi2yqMKeopA4nH08WiueaXLf2II/muC2AZrR8ej+ksO0DbqVUT5upGazTZkUkVr670dPMEfeqvCOIJoU4rZvarU2LXKYlrJ3FRb8QIQjLdonIq649a4mrHI1Vq9Hhc7W8s0iUtNpPi5xpNJqtRwvUJytZ/SawsJHJS0Lhv2tncSN47fWr3xM+mvav4Z/qDzOGjVHW3kCNcW9ttnYdiZYKSGIHv2rJ3g7pNq7cRju+RjtfcNp3KMGRg1rtDa017hOm4ZxLRHUX9HYtc/Sup3iyMLc07TkqIyrenXB799oT6jW8DbSf+s1OkvaLax1CavTu6mADbCtchRBEnBmAB0zjeGcd1eh4vyuHaG9rNPrbtvTNaKk6tkUm61w7YCnxlzOACAYrnce4br14sRwexxC9oALb6ZkuO7KGUbhv1XiVgZBkSK2HwboL/D7Ots39LZ07ai9/UWwlx792CoDLf1D5ZiRuMCPtUDY6cOttEJ+UR9Knjp3qK3IBqQVANYn450538H1QB6anTOR6hXX+9bWuH8U2w3CLt7bu/pL1jUxPUBth/mruPbxy1lxeN1lhrCOCsCSGEd+i+VHU27i61brq6pqij2w+CWUAMY+1WbHEdAltLj2ZIVMBgOp61V4jxNtU+jvclUTT3L+zuTvAiftXv6t608/5da2un01gXLxA8E59WrrfC+sTW6jjT2x+Fp+RaUx1Lb2OftWId9brSs7tvhUDygTW1+C9G+k4fr3uAhtRrN2eu1Lar/zWbl/jhn/0sxR+cNLGadGKYTmiK8NvBuk+WaaUkSvU9qfEnpjvTQdm5W7eIeo8qCvbBbUPj5LSp9Xbcf2Aqa9+Q+RptjxM1w/+45ufSNq/tTr48IqYEdwjmT7H9qZcO29PYwf2o3MFT5qD/amXslD/AKVqQcF09Wn7VK2ZNV7Um6P9Kk/fFTz1HeoD1fwxUtp+o7VVnawnuBUiGe3ep1sWnDHaVOJEjzBpxRIwo71GjEYqQywwYzXAr73/AFHy61Y5dv8ASPtS5dv9P7moDcufqP7UALuC3iOCYz5VOqIVBKgkjM0giEAlRJyahLuCwBwDA6UCZmDMASADgTFLe/6j96mVVZVYrJOSaPLt/pFBCbtwEif4qQW7ZgkZOep70eVbnv8AeojduAmIgY6dqAG46kgHwiQMDtUq20YBiJJEnJpC2jCTMtk5qMu6kqIgYE0CZmRmVTAGAOv809EV1DOJY4Jk0giOAzTLDMGmszWyVWIAxNAnLWztQwImOv8ANQXHZn8XUACrKqtwbm69MYqi58b+5rqqFH4gU3eB8Sj5rS2b6+Y5dxZ/asfodZzwbdwjmqAAf1jz963GqUXtFxCxEi5pNQseZ5ZYfuK8t090peQzBnNdRG+ktGxGQe3n1rna61zbTADIG5TVizdd5VhJEkEfwaV2CPfFV2jRDm6S6WTYSd6f2qU6niCa/h2suaq+9rh7Wm09hHZIG4m6pbpDjFUbk6bVBhhWwf8ANW3IZZwf+KiJS9K0Wo4dxS0ur04S4j4aVHMRx1S4I6irQsIplQAR0+leYcM4nrOE6rnac7kaFv2WMJeQHofUflPavSdBxHR8S06anTPKnwujRzLTxlLg8/5rv2hdWYGMd6kFRIwBj6in7+1A4mqXFLI1PDeKWP8A7XR6hV/3bCRVkmhgwD0bwn1BwaROp2iXjegAcXSbSX7y8oWrV/CcuCS4G4e2au3LFtv6sWUt8m0Gbm72aGAV2RD0MGajWzYt3b9m5bRmsXntDcs7dtxlNXCt50Ko6Lb2X1AgREQYHSvoq7nvbzrddJdOyoFZNuWQ+mVrZ/Dpb/ym27GTc1GpJJ8g+wfxXmGj1zGwgJJIC9f9JivUOAqy8F4Tu63LLXz/APquzj+ayc3rHH9rsMfnt0yaeAIDT6VHE00qxEAkRXjNiYEdiKg1LqijdPXb4QSxJxAAzTHtrsID3LcGZtkSTMxkHr3qNLSLc5zF3uZCl2JCg9lXoKkWLLW2QvbZWQeGVOAVxtPrTyN6EYnJj2E1y9TreGaPiPDtMwvDWa8stvkDwEZzdEx2OYNXCxtl2BMsxJkzk967vS1YiZj2iJieoG54rFtu6kg+1V7p8Nk+hH2q0mbBXzUkVUuf9JfRzUJOsfnbzMfanliGFNsiEHtuPuaB6/WglbKg+Rp6dfc1GskR5xTg4V1t4iPGw7E9AKCzvAwsk0RunymgtsKZFPOYoHjdB8+x8qXKt+Xvk0RMCaje46sQCIHpMYrmQzmXASJ6GOgqUW0YAkSTBOT1pC0hAJmTk5qM3HUlREAwO9QEzurFVOFMAQKHMuef7CpBbRwGaZbJg0eTb9fvQMN5weg+1OFlDBls5PlSNlT+Y03nMMbRAkT7UCN11JUAQCQMeVOFtXAYky2THShylbxFj4sxjvS5hTwgAhcCetAC7ISg6LgT186cqC4N5Jk+XTFDli54ySC2Y7DtSLm14AJAzPvQInlnYOkTJ65qjfBVg3Zqt3CWUP3nbHtULgOCp+h7VZVCqlxA6q5gMQD6g4NeTXQ1nU37R62tRctn/wDK5WvUbyQdrSB2NeYcWeynGOI2kfdOoLg9iHAeR96n5S72kwgaOo70++sSexyKp6fVqot27/hBACXB09mroOoZeoKsPCVyPea6tG4RvTi622LqMe4E/UVDpb262Ub5lwZ61bvAqWVuorlE8m/6PWd0t3BEx2qzw/ier4bqE1OnbJ8N62x/DvJ+lx/BqoWkA1XuPtPsKROh6vw7iuk4lYTU6ZjIIF20/wD1LT91Yfwe9dQMsBh0MZ868c0PEtRw6+uo09zawAVwcpcTrtcdxXpfBuMaTidgPYI5i/8AUtMQWtP3Ht5Gu4naHZJA96jZqYSZkn7UJmg8z4uBpeNcatMSAdVzV/23Yuj+agDadiZusMXYAmul8XW7dvjKucf1Oh09zPc22a0f4rjDlofGk5uQR7TX0OCfLHEvPyRq0ufo1/CuRiEuR79a9p0VtbOi4dZGBb0emT2221FeRcPsjZYRjm+4tgd/xHCf3r2MgKdo6KAo9gIrDzp6rVfh7mZPEUIGabNJ3UKWP5R09ewry2lDeYbgq/lyfeow0sg7zmmuwUEk5OT9ait3B/UW5MD5j7DJqysb6RPTNX7p1fxxplBJTQBk9jasMT+7GtSzyaxHw5c/rfiHimsmQberuggzJvXQB9hW3Fm85G1GjzIgfvXp/UqxS1Mf7Vhm425i0z+6wpgW180P71Vvgi20ddw/mKttZYLbZmjYsQMkn1qnecKsnpIPvGYry2pJbbJXtEfagesVDbJEE9etTjLenf2oEX2KAPnfp5Be5NFduDEVH8zFvPp7dqk6dKgWRfG0KQZ6UOYWMLJM5jtVPe1y4bVn8p/Gun5U/wBCnux/anve2ubFkEbTtuMepPkKkX0ZUbaWlj1EzFPIRz09JHaoLFjAZiR3I7n3NXAABAFcSK/NcSPDiR9qfylaGJOcmIjNFrSsSZIny7UzmMvhAB24n2qAjcZCUEQuBIpc5/IfaiLavDkmWyY6UeSv6jQA3iCRt6eppcmc7uuennSNk58Q+1LnAY2nGOtAOaVlds7ZHU5ijyt/i3RuzETFDklvFIG7MQcTmncwJ4IJ24mgHMNvwRIXE9PWls5njmJ7RNI2zc8YMTmIpBxa8EEx396AER+H1jxT061DdO1raDrBNTjxHf0nBHtVO486lvJVAruqJM1FpbqFW6kEA968W49bfR8cuWnwym2D6gYB+oivYNXfNu4mYFYD/wAQuHgnhfGrS9GGl1RHkTuRj9ZH1rqRz01SXZtOB5AiptPrLulcIxLWScg9vauA91kuqwPUKw+tXzd3KrelTFjTu6nZeRb1sg4+4/xXH1S7gGHUZqxotULWLhHKPzBv5FN1L6WbjWX32jlTER6Ga4vHylXtXNywTkYqDUsBNQtfCXNydPKq13UNcYmq9J2k5jHHep9FxfWcJ1NrUaZ4cMJUmFcT8rehqrbz4vSobtk3G9a6Q930uot6zTabU2o5d60lzB6EjI+lTY7ZrLfBV/dwHQW3JItXdRpyT2KXDFaobckDp1NdDD/Hmm5h4FqcwjazTsFMbyQt1FJGezVlUvXLZs7UgvuL22JYrB2znzrd/GenTUcD1FxhnS6nT6hSJBEsbRIj3rzy0UWPEV8SyZknHc16vDmZqy5Y72vcB5mp41wPTn5f/MULf7bTG6f4r2EySSe5mvK/gy0LnxBo3InkpxC/9QmwH/5V6lms/Ond4j+FmGNQPXvUF1tzrb/SZb3Pb6VI7hFLdx0HmagtAlpOTkk+dYYXH4gEgHJGRPehCfpX7CkWG1ZMd/vmgpBPUV0OfwXTWLfGPii9atW0VDoNMgRQolbPMcgDGSa75Jg1T0enTSniF3mb21mp/qTiNv4aWwn0j96m5mDg9qtzX+5bf8R/kOMcag+8YtfSuTqFLrEwQQRPpXRvsSoHTFc90LmIPQVVDsLZwPoDGRNTr0NKxoLiq9xnw0bVjv5zSdLwO1EJckBcSPcxTreoCLqsDueg86q3NYCpW2HbxBCbQ3O7H/27U4n9THA96luaW6xZbhKiYfOW9CR2qRFtWQI2qIiTjFA7Tm+ltA621aZKJOxPQdzU1tVVrjwWuXGLMzdST5U03NPbG53AnpP9gM0k1dt45QLDzAIH71yLINw9Knt7wIbp2qO1cYmGAyMYqeokB22jd5H+aj5W7xbo3Z6DvT3Usu3uSP5pnNCeHb8uMVAXMKeCJ24metLnn9P7mly9/jmN2YiaXJ/1D7UBN5RPhNN5LHMrBz96RsuSekH1p3NQQM4x0oBzQoCwfD4Z9sUDbZyWBENkT1oG0zEsIgyRJ86eLioApmVEGOlABcFsBCCSuCRQKG6d4IAOM9aRRnJdYhsiTmnB1tja0yJ6dM0AHhGw5IzI6ZrlM8XrjebGuqfFucTt2xnzFcq8pBYjAyc1ZVCjxIFrRYdVzXF1ypxTgvEtGwljYcp6XEG9T+1dq+wKXASI2mswl86fVXEJi2xJMnAFJS8/d91qw/Q7QD6EYq1YvTbAye1c69et87V2lyi6m/yz227zFWdIdxIGYEmO1cjogFxB6UOJWb2kt6YyDbvKW8Eyrd1b1p1pvEpbABBrUcM5DKHJJDHptxjsZrvWxgA+Z6gjzogeKOxra/EfCNLetrqtHYRL6H8ZLQVTcQ/mCeY71jntsrADrXExoTrhYp6W3ciBQtW5gE1eUqqgKKDW/BjRw3X2Cc2eI3h7C4iOK19u9zFhmMpggd46GsR8I3ALnHbfSbukvAf7rZX+1asMUYOMlevqO4rqI6C4za/qeEcYsASX0Oo2g/qReYP4ryG3cI24k+A56dK9plb67RlbyMnpDqVj968UdGs3bloxNq4bZnoSjFTW/hzqJhRlhsP/AA9Vn4pxm4f/AGdGEB7A3rwP/wDWvSCwwKwX/h1bK2fiXUno+t02nU//AIdo3DH/AO6ttcfG38x+b0HlWbkT5ZJWUjVTLrb2gfKvT1mpLcAMT2BqIZipGIVAJyzfsM1Q7MbJ9jSX5hQJ70rZlx9zQXOgA9KbFHcCaXlQNv8Ayrn0p1m0oVbriQYhR5jGah1D5AHlJq3a8dm0g+YAMZ6VEiQtzAEUEdxPTFAIbfjMEDsKSqbR3t06Y9acXW4NizJ6T0xmuRVvK1wsUhZ6zk1z7mlfepa6SRBgiR9q64tsrBjEDrB7Vndb8QcGs3H/ABbt5pI26a0zRBjLPtX96TetI/KXdKWv+mNryoQ25rjGO0CP3qZIQ+BQFPUAZBPcVm7vxRb/APpdC7DEPqrgT/4WpP8A8qpXeM8b1YZBfXTofCV0ibGIPncYlv3FZL83FX521V4Wa3uNN5aBkEnHUVZHl3rDaE8Q220fX6sog2opvPEfzWo4fbFlGd2dnfEsSx2j/canFyYyz+MK8uCcUdyvm6inufbtTDaZjuBHizQ5TmSIg5608XFUBTOMGtTMAuBIQgkriRR5y/pamm2zksIhjInrS5NzzFBJzbfr9qiNq4ZIAzJGfOgV65qyOg9qCMXUUAGZGDjuKjNt2JZRg5E4oMpLPn8xqwghVHpQRh1QBGmRg4mmspuEsoG0jEnOKVxZdjPepLYhB9aCtfvNp7D7ULXPyqOni71xbj6q6Wa44AOTCiBXfurLfQU+0oCmQDnyFdRbSGUuIY+dY/21k/iFdVprb6jkF7BkNcsLclB5vEivVbqAlYA6HsKNpFhwQCDHYVPkl8u3L1nnXitwFS7EHOQTNdfhl20iFwVbfIM9a+iLmn0+CLNnJM/h28/tStWbQn8O307Ig/gVzseFobd0qAVUAyT5T51Ne45b0if0ukuo1+PFcM7Lf+a9wuWre3CW5kfkX/imW7Frdm3aiDjlp/xSZnXTqsxE9w8AW9fuMbraxndupYmpbvLa2t4MBBCv5Bv81761mztMW7YPmEX/AIpi2be5RstxORsXP7VxWLR7l1e9bR1Gng1ko5w4irqraA+YV7ibVra0W7fQ/kX/AIqAW1lfCnUfkX/iu9q3l3w1ctrxPiNtWH4ug092B527rL/etjvUgZrUi3bBkIgMESFWYP0qvyx6fYVMWHB094K2ycEgr6N5V5TxwW7HGeM2TcTauvvgEYKlm3wfvXvu1fIfYVVa0hZiUtmSZm2p/tVuPP8Abnbm1fLpivgJETgF68IPP4nrLgI77QlofxWkMkknrOa7NtFVVAVQOsKABPsBUTp42yOvlXFr+U7TEajTmjBFOunKDyWfvXVtqAqyB37etR3F8R6dB2rnaXIJNSWYBJ7xXWtKNvQZJ7Cm3VysQMHsPOmxRBNGD4ZPU1etKBu75H8Urqzt+tNjmqhv6jYuRMt/tFdBFNsywhYgRmjZWCekx5etOuiVH+4VAazC4NqTMjBx0pqo1shmHhHWDRtLDTPY1LcEofcfzUDhfEXGLeg0htW3jU6lWVfNLfRm9+wrzvmK5JLCSa9aW2CyyFOT1AP81K1q1DQiDB/Kv/FYs/Gtlnfk38flRgrqK7eTJskAMD510dOi+HxDBr0JbSyvhTqPyrU+xM+Be/Yf8Vlj6dqf1f4vt9R8v+f9ZjhmnFxlP5QQWPkPStDyX7AR2z2obPb7Var0MOGMUah5+bLOSdo+bbEAzjBx5VGbbsSwAgmRnzoMhls9zVhR4V9hV6kxXRAFMyogwKPNt+v2qJlJd/ehs9R9qD//2Q=="
    },
    {
      "id": 6,
      "docName": "Thiya",
      "docMailId": "Thiya@gmail.com",
      "rating": "5",
      "qualification": "MA,Psychology",
      "specialization": "Pschiatrist",
      "overallExperience": "18",
      "consultationFees": 1200,
      "location": "Chennai",
      "profilePhoto": "https://th.bing.com/th/id/OIP.cKgLEoLgzgCAaAoAOBCKkgHaE8?w=246&h=180&c=7&o=5&dpr=1.5&pid=1.7",
      "detailedDesc": "Dr. Thiya is a Pschiatrist in chennai City, chennai and has an experience of 9 years in this field.Dr. P.Ezhilan practices at E.B.K Medicals in Thanjavur City",
      "availableTime": "Monday to Friday 9AM to 6PM",
      "address": "yadhaval street,chennai,sholingnallur"
    }
  ],
  "doctordetails": [
    {
      "date": "12.06.2021",
      "doctorId": 1,
      "slotTime": "11-11.30AM",
      "location": "Chennai",
      "isBooked": true,
      "id": 10
    },
    {
      "date": "13.06.2021",
      "doctorId": 3,
      "slotTime": "11-11.30AM",
      "location": "Mumbai",
      "isBooked": true,
      "id": 9
    },
    {
      "date": "12.06.2021",
      "doctorId": 4,
      "slotTime": "11-11.30AM",
      "location": "Mumbai",
      "isBooked": false,
      "id": 8
    },
    {
      "date": "12.06.2021",
      "doctorId": 5,
      "slotTime": "11-11.30AM",
      "location": "Mumbai",
      "isBooked": false,
      "id": 7
    },
    {
      "date": "12.06.2021",
      "doctorId": 6,
      "slotTime": "11-11.30AM",
      "location": "Mumbai",
      "isBooked": false,
      "id": 5
    },
    {
      "date": "12.06.2021",
      "doctorId": 2,
      "slotTime": "11-11.30AM",
      "location": "goa",
      "isBooked": true,
      "id": 12
    },
    {
      "date": "14.06.2021",
      "doctorId": 8,
      "slotDetails": [
        {
          "slotTime": "12-12.30PM",
          "location": "chennai",
          "isBooked": false
        }
      ],
      "id": 13
    },
    {
      "date": "14.06.2021",
      "doctorId": 8,
      "slotDetails": [
        {
          "slotTime": "11-11.30AM",
          "location": "goa",
          "isBooked": false
        }
      ],
      "id": 14
    },
    {
      "date": "12.06.2021",
      "doctorId": 2,
      "slotTime": "12-12.30PM",
      "location": "Manglore",
      "isBooked": true,
      "id": 15
    },
    {
      "date": "14.06.2021",
      "doctorId": 1,
      "slotTime": "11-11.30AM",
      "location": "chennai",
      "isBooked": true,
      "id": 16
    }
  ],
  "users": [
    {
      "firstName": "moni",
      "lastName": "kumar",
      "email": "Ramco@gmail.comn",
      "password": "123456",
      "confirmPassword": "123456",
      "acceptTerms": true,
      "id": 1
    },
    {
      "firstName": "karthiga devi",
      "lastName": "kumar",
      "email": "karthika@gmail.com",
      "role": "admin",
      "password": "123456",
      "confirmPassword": "123456",
      "acceptTerms": true,
      "id": 2
    },
    {
      "firstName": "Thiya Alison",
      "lastName": "kumar",
      "email": "Thiya@gmail.com",
      "role": "admin",
      "password": "123456",
      "confirmPassword": "123456",
      "acceptTerms": true,
      "id": 3
    },
    {
      "firstName": "Shantha Kumar",
      "lastName": "sivakumar",
      "email": "santha.govindan@merck.com",
      "password": "123456",
      "confirmPassword": "123456",
      "acceptTerms": true,
      "id": 7
    },
    {
      "firstName": "Thiyagarajan",
      "lastName": "sivakumar",
      "email": "Thiyagarajan@gmail.com",
      "password": "123456",
      "confirmPassword": "123456",
      "acceptTerms": true,
      "role": "admin",
      "id": 8
    }
  ],
  "userappointments": [
    {
      "apptDetails": {
        "timeSlot": "11-11.30AM",
        "date": "12.06.2021",
        "slotId": 10,
        "docName": "Karthika Thiyagarajan",
        "location": "Chennai"
      },
      "userId": 7,
      "docMailId": "karthika@gmail.com",
      "patientName": "Shantha Kumar",
      "id": 1
    }
  ]
}