import SelectedDoctorChild from './SelectedDoctorChild';
import { useParams ,useHistory} from "react-router-dom";
import React, { useEffect} from "react";
import { useDispatch, useSelector } from "react-redux";
import {fetchSelectedDoctor} from "../../redux/actions/doctorsListAction"
import {postAppt} from '../../redux/actions/appointmentsActions';
import {putDocDetails}  from '../../redux/actions/doctorsListAction';
import { patchData } from '../../api/api';
/**
 * 
 * @returns SelectedDoctor component
 */
const SelectedDoctor=()=>{
    const params = useParams();
    let paramID = params.id;
    let history=useHistory();
    let dispatch=useDispatch();
    const userLoggedin = useSelector((state) => state?.users?.usersList);
    const { id,firstName } = userLoggedin[0];
    let { selectedDoc, isLoading } = useSelector(
      (state) => state?.doctors
    );

    const {docName,doctordetails,rating,detailedDesc,address,profilePhoto} = 
   useSelector((state) => state?.doctors?.selectedDoc);

  /**grouping list data based on time */
  const groups = doctordetails.reduce((groups, item) => ({
    ...groups,
    [item.date]: [...(groups[item.date] || []), item]
  }), {});
  console.log("grp",groups)

  /**forming array */
  const objArray = [];
  Object.keys(groups).forEach(key => objArray.push({
   date: key,
   slotValues: groups[key]
  }));
  console.log("array",objArray)
    
    /**
     *fetching the selected doctors data
     * @returns axios response
     */ 
      useEffect(async() => {
      //fetching the details of selected doc
      try {
         dispatch(fetchSelectedDoctor(paramID)); 
      } catch (error) {
        console.log(error.message);
      }
    }, [paramID]);

   
    /**
     * 
     * @param {number} id push to appointments page
     */
    const selectedSlot=(data,slotTime)=>{
      //marking slot as booked in DB
      // let patchObject={"isBooked": true}
      // let response=patchData(`doctordetails/${data.id}`,patchObject);
      //forming object for success appt posting
      let apptObj={"timeSlot":slotTime,"date":data.date,"slotId":data.id,"docName":selectedDoc.docName,"location":selectedDoc.location}
      let appointment = {apptDetails:apptObj,userId:id,"docMailId":selectedDoc.docMailId,"patientName":firstName,"address":selectedDoc.doctordetails[0].address};
      dispatch(postAppt(appointment));
      history.push('/myAppointments');
    }

    return (
        <SelectedDoctorChild selectedSlot={selectedSlot} objArray={objArray} doctordetails={doctordetails}/>
        
  );
}

export default SelectedDoctor;