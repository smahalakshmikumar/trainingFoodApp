import React from 'react';
import NavigationBar from "../../../UI/NavigationBar"
import { Button } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import Snackbar from '@material-ui/core/Snackbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
/**
 * 
 * @param {object} selected doctor info
 * @returns SelectedDoctorchild component
 */
const SelectedDoctorChild=({selectedSlot,objArray,doctordetails})=>{
  const {docName,detailedDesc,address,profilePhoto} = 
   useSelector((state) => state?.doctors?.selectedDoc);
   //MATERIAL ui
   const [open, setOpen] = React.useState(false);
  console.log("hi",doctordetails)


  /**
   * @param {string} reason - clciking away to close
   * @returns 
   */
   const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  
  /**
   * 
   * @param {number} id 
   * @returns triggers parent book slot click
   */
  const selectedSlotClick=(data,slotTime)=>{
    selectedSlot(data,slotTime);
  }

    return (
        <div class="container-fluid">
        <NavigationBar/>
        <Snackbar severity="success"
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message="Added to cart"
        action={
          <React.Fragment>
            <IconButton size="small" aria-label="close" color="inherit" onClick={handleClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
         <div class="accordion" id="doctorsList" style={{padding:"10px"}}>
        <div class="accordion-item">
          <div id="collapseOne" class="accordion-collapse collapse show" 
          aria-labelledby="headingOne" data-bs-parent="#accordionExample">
            <div class="accordion-body">
              <div class="row">
              <div class="col-md-3">
              <img src={profilePhoto}
              class="rounded" alt="profile"/>
              </div>
              <div class="col">
              <h3 style={{color:"blue"}}>Dr.{docName}</h3> 
              <h6>{detailedDesc}</h6>
              <p>Address: {address}</p>
              <strong>Book Slot:</strong>
             
                {objArray?.map((data,index)=>(
                  <>
                  <p>{data.date}
                  {data.slotValues.map((slots,index)=>(
                    <Button style={{margin:"10px"}}
                     variant="info"
                     id="selectedSlot"
                     onClick={()=>{selectedSlotClick(data,slots.slotTime)}}>{slots.slotTime}
                     </Button>
                  ))}
                  </p>
                  </>
                  ))} 
             
              
              </div>
              </div>  
            </div>
          </div>
        </div>
        </div>
        </div>
  
  );
}

export default SelectedDoctorChild;