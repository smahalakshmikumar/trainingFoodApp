import React from 'react';
import NavigationBar from "../../../UI/NavigationBar"
import { Button } from "react-bootstrap";
// import ReactStars from 'react-stars'
import LoadingIndicator from "../../../UI/loadingIndicator/LoadingIndicator";


/**
  
 * @param {array} doctorsList- to populate list of available doctorsList
 * @param {viewMore} function triggers parent
 * @returns DoctorsListChild component
**/
const DoctorsListChild=(props)=>{
    const {doctorsList,viewMore,isLoading} = props
    /**
     * 
     *@returns triggers parent view more
     */
    const viewMoreClick=(id)=>{
      viewMore(id);
    }
    return (
      <div class="container-fluid">
      <NavigationBar/>
      {isLoading ? <LoadingIndicator color="secondary" /> : null}
      <div class="accordion" id="doctorsList" style={{padding:"10px"}}>
      <h2 class="accordion-header" id="headingOne">
          Available Doctors
      </h2>
      {doctorsList?.map((data) => (
      <div class="accordion-item">
        <div id="collapseOne" class="accordion-collapse collapse show" 
        aria-labelledby="headingOne" data-bs-parent="#accordionExample">
          <div class="accordion-body">
            <div class="row">
            <div class="col-md-3">
            <img src={data.profilePhoto}
            class="rounded" alt="profile" style={{height:"15rem"}}/>
            </div>
            <div class="col-md-8">
            <h3 style={{color:"blue"}}>Dr.{data.docName} </h3> 
            <p>{data.qualification}</p>
            <p>Overall {data.overallExperience} years of experience</p>
            <p style={{color:"blue"}}>Consultation fees:Rs.{data.consultationFees}</p>
            <strong>{data.location}</strong>
           
            <p><Button variant="info" id="viewMore" onClick={()=>viewMoreClick(data.id)}>View More</Button></p>
            </div>
            {/* <ReactStars class="col-md-1"
            count={5}
            value={data.rating}
            size={24}
            color2={'#ffd700'} /> */}
            </div>
          </div>
        </div>
      </div>
        ))}
      </div>
      </div>
);
}

export default DoctorsListChild;