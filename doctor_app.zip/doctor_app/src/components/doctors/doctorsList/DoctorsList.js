import React, { useEffect,useState } from "react";
import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import DoctorsListChild from './DoctorsListChild';
import {fetchDoctorsList} from "../../redux/actions/doctorsListAction"


/**
 * Doctors list page
 * @returns Doctors List component-- displays list of docs
 */
const DoctorsList = () => {
     
      let history = useHistory();
      const users = useSelector((state) => state?.users?.usersList);
      let dispatch = useDispatch();
      //fetching role from users
      //const { role } = users[0];
      //getting  doctors list,setloader from store
      let { doctorsList, isLoading } = useSelector(
        (state) => state?.doctors
      );

      /**
       * fetching the List of DoctorsList
       * @returns dispatch fetch DoctorsList
       */
      useEffect(() => {
        try {
          //dispatching api action through thunk,storing in redux and displaying
          dispatch(fetchDoctorsList());
        } catch (error) {
          console.log(error.message);
        }  
      }, []);

      /**
       *  on selected doctor click,push to next page
       * @param {number} id -pushing to next page based on id
       * @returns history.push
       */
      const viewMore = (id) => {
       history.push(`/doctor/${id}`)
      };
      

      return (
        
        <div class="container-fluid">
          <DoctorsListChild doctorsList={doctorsList} viewMore={viewMore} isLoading={isLoading}/>
          {/* {props.children} */}
        </div>

      );
};
export default React.memo(DoctorsList);
