import React, { useState } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useHistory } from "react-router-dom";
import TextField from '@material-ui/core/TextField';
import SweetAlert from "react-bootstrap-sweetalert";
import * as api from "../api/api"
import { useSelector, useDispatch } from 'react-redux';


/**
 *  To add new slot
 * @returns AddSlot component
 */
const AddSlot = () => {
  const history = useHistory();
  let docId = useSelector((state) => state?.doctors?.selectedDoc.id);
  return (
    <Formik
      initialValues={{
        slotTime: "",
        location: "",
        date: "",
        doctorId: docId,
        isBooked: false,
        fromTime:new Date(),
        toTime:new Date()
      }}
      validationSchema={Yup.object().shape({
        location: Yup.string().required("location is required"),
        date: Yup.string().required("date is required"),
        fromTime:Yup.string().required("from time is required"),
        toTime:Yup.string().required("To time is required"),
      })}
      onSubmit={(fields) => {
        //To time should be greater than from time
       if(fields.fromTime>fields.toTime)
       {
         window.alert("To time should be greater than from time");
         return;
       }
      let toTimeVal= fields.toTime.getTime();
      console.log(toTimeVal)
       let timeDifference=fields.toTime-fields.fromTime;
       console.log(timeDifference);
       
       let slotTime= `${fields.fromTime} - ${fields.toTime}`;
       console.log(slotTime);
      //  let formattedDate=fields.date.toLocaleDateString();
      //  console.log(formattedDate);

        let items = { "date": fields.date, "doctorId": docId,
         "slotTime":slotTime, "location": fields.location, "isBooked": false,"fromTime":fields.fromTime,"toTime":fields.toTime };
        try {
          api.postData("doctordetails", items)
            .then((response) => {
              history.push(`/doctor/${docId}`);
            });
        } catch (error) {
          console.log(error.message);
        }
      }}
      render={({ errors, touched }) => (
        <Form className="form">
            <div class="container">
              <div class="row">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                  <div class="card card-signin my-5">
                    <div class="card-body">
                      <h5 class="card-title text-center">Add New Slot</h5>
                      <div class="form-label-group">
                        <label htmlFor="fromTime">From Time</label>
                        <Field
                          name="fromTime"
                          type="time"
                          className={
                            "form-control" +
                            (errors.fromTime && touched.fromTime
                              ? " is-invalid"
                              : "")
                          }
                        />
                        <ErrorMessage
                          name="fromTime"
                          component="div"
                          className="invalid-feedback"
                        />
                      </div>

                      <div class="form-label-group">
                        <label htmlFor="toTime">To Time</label>
                       
                        <Field
                          name="toTime"
                          type="time"
                          className={
                            "form-control" +
                            (errors.toTime && touched.toTime
                              ? " is-invalid"
                              : "")
                          }
                        />
                        <ErrorMessage
                          name="toTime"
                          component="div"
                          className="invalid-feedback"
                        />
                      </div>
                      <div class="form-label-group">
                        <label htmlFor="location">Location</label>
                        <Field
                          name="location"
                          data-testid="locationField"

                          type="text"
                          className={
                            "form-control" +
                            (errors.location && touched.location
                              ? " is-invalid"
                              : "")
                          }
                        />
                        <ErrorMessage
                          name="location"
                          data-testid="locationError"
                          component="div"
                          className="invalid-feedback"
                        />
                      </div>
                      <div class="form-label-group">
                        <label htmlFor="location">Date</label>
                        <Field
                          name="date"
                         type="date"
                         dateFormat="dd/MM/yyyy" 
                          className={
                            "form-control" +
                            (errors.date && touched.date
                              ? " is-invalid"
                              : "")
                          }
                        />
                        <ErrorMessage
                          name="date"
                          component="div"
                          className="invalid-feedback"
                        />
                      </div>
                      <button
                        class="btn btn-lg btn-primary btn-block text-uppercase"
                        type="submit"
                        style={{ margin: "10px" }}
                      >
                        Submit
                      </button>
                    
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </Form>
     
     )}
    />
  );
};
export default React.memo(AddSlot);
