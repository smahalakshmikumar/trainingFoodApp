import MyAppointmentsChild from './MyAppointmentsChild';
import React,{useEffect} from "react";
import { patchData } from '../api/api';
import * as api from "../api/api"
import { useSelector ,useDispatch} from 'react-redux';
import { FETCH_SAGA_SUCCESS_APPTS } from '../redux/actions/actionTypes';
import {deleteAppt} from "../../components/redux/actions/appointmentsActions"

/**
 * 
 * @returns MyAppointments component
 */
const MyAppointments=()=>{
    let dispatch=useDispatch();
    let appointments;
    const userLoggedin = useSelector((state) => state?.users?.usersList);
    const { id,role,email} = userLoggedin[0];

    /**
     *fetching the appointments data
     * @returns axios response
     */ 
     useEffect(async() => {
      //fetching the appointments details for admin/normal user
      try {
        dispatch({
          type: FETCH_SAGA_SUCCESS_APPTS,
          payload:id
        })
      } catch (error) {
        console.log(error.message);
      }
    }, []);
    appointments=useSelector((state)=>state?.appts?.confirmedAppts?.userappointments)


    /**
     * 
     * @param {array} data.id to delete appointment
     * @returns dispatch cancel appt action
     */
    const cancelAppt=(data)=>{
       //marking slot as booked in doctorDetails table
      // let patchObject={"isBooked": true}
      // let response=patchData(`doctordetails/${data.id}`,patchObject);
      //  let patchObject={"isBooked": false}
      //  let response=patchData(`doctordetails/${data?.apptDetails?.slotId}`,patchObject);
      //  //then delete from appointments table
       dispatch(deleteAppt(data.id,id));
    }
  
    return (
         <MyAppointmentsChild cancelAppt={cancelAppt}
          appointments={appointments}/>
        
  );
}

export default MyAppointments;