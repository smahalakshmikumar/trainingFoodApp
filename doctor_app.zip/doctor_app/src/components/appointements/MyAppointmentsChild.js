import React from "react";
import NavigationBar from "../../UI/NavigationBar";
import { Button } from "react-bootstrap";

/**
 * @param {array}appointments list
 * @param {function}cancelAppt function
 * @returns MyAppointmentsChild component
 */
const MyAppointmentsChild = ({ appointments, cancelAppt }) => {
  
  
  /**
   * 
   * @param {array} data array 
   * @returns triggers parent's cancel appt
   */
  const cancelApptClicked = (data) => {
    cancelAppt(data);
  }
  return (
    <>
      <NavigationBar />
      {appointments != null && appointments.length > 0 ? (
        <div class="card" style={{ width: "40rem", margin: "20px" }}>
          <div class="card-header">
            <h4>My Appointments</h4>
          </div>
          {appointments?.map((data) => (
            < div style={{ margin: "20px" }}>
              <h5 style={{ color: "blue" }}>Booked Dr.{data.apptDetails.docName}</h5>
              <p>Time:  {data.apptDetails.timeSlot}</p>
              <p>Date:  {data.apptDetails.date}</p>
              <p>Location:  {data.apptDetails.location}</p>
              <div class="card-footer"><Button variant="danger" id="cancelClick" onClick={() => cancelApptClicked(data)}>Cancel Appointment</Button></div>
            </div>
          ))}
        </div>
      ) : <h1>Book Your Appointments</h1>
      }

    </>
  );
}

export default MyAppointmentsChild;