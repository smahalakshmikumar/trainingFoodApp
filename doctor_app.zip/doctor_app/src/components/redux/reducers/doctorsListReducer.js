import {
    FETCH_SUCCESS_DOCTORSLIST,
    FETCH_FAILURE_DOCTORSLIST, SET_LOADER,FETCH_SUCCESS_DOCTOR
} from "../actions/actionTypes";

  const initialState = { doctorsList: [],selectedDoc:[],
  isLoading: false, error: "" };
  /**
   * doctorsListReducer to perform fetch success,failure and set loader actions
   * @param {array} state - displays state 
    * @param {object} action -action object that has type and payload
   * @returns updated state
   */
  const doctorsListReducer = (state = initialState, action) => {
    switch (action.type) {
       case FETCH_SUCCESS_DOCTOR:
         let success={ ...state, selectedDoc: action.payload,error: "" }
         console.log(success);
        return success;
        case FETCH_SUCCESS_DOCTORSLIST:
        return { ...state, doctorsList: action.payload,error: "" }
       case FETCH_FAILURE_DOCTORSLIST:
        return { ...state, error: action.payload, doctorsList: [] };
       case SET_LOADER:
       return {...state,isLoading:action.payload}
       default:
        return state;
    }
  };
  
  export default doctorsListReducer;
  