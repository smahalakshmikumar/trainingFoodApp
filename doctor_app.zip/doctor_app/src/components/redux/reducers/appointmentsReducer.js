import axios from "axios";
import * as api from "../../api/api"
import {
    ADD_TO_APPT,REMOVE_FROM_APPT,CLEAR_APPT,FETCH_SUCCESS_APPT
} from"../actions/actionTypes";

const initialState = {
    
    isLoading: false,
    confirmedAppts:{}
  };
  /**
   *const appointmentsReducer = (state = initialState, action) => {
    reducer to perform add,remove,clear cart
   * @param {array} state - displays state 
   * @param {object} action -action object that has type and payload
   * @returns cartList data
   */
  const appointmentsReducer = (state = initialState, action) => {
    switch (action.type) {
      case FETCH_SUCCESS_APPT:
        return  {
          ...state,
          confirmedAppts: action.payload,
        };;
      default:
        return state;
    }
  };
  
  export default appointmentsReducer;