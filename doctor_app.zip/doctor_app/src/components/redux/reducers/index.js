import { combineReducers } from "redux";
import doctorsListReducer from "./doctorsListReducer"
import loginReducer from "./loginReducer"
import appointmentsReducer from "./appointmentsReducer"


/**
 * Root reducer to combine reducers
 */
const rootReducer = combineReducers({
  doctors: doctorsListReducer,
  users: loginReducer,
  appts:appointmentsReducer
});

export default rootReducer;
