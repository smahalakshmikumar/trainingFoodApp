import { getData } from "../../api/api"
import { FETCH_SAGA_SUCCESS_APPTS } from "../actions/actionTypes"
import { call, put, takeLatest, cancelled, delay } from 'redux-saga/effects'
import { fetchAppt, fetchFailure, setLoader } from "../actions/appointmentsActions"


/***
 * generator function appts saga //worker saga
 * @returns axios response
 */

export function* fetchApptsWorkerSaga(action) {
   try {
      yield put(setLoader(true));
      let response = yield call(getData,`users/${action.payload}?_embed=userappointments`);
      yield put(fetchAppt(response.data))
   }
   catch (err) {
   } finally {
      yield put(setLoader(false));
   }

}

/**
 * watcher saga
 * @returns FETCH_SAGA_SUCCESS_APPTS
 */

export function* fetchApptsWatcherSaga() {
   yield takeLatest(FETCH_SAGA_SUCCESS_APPTS, fetchApptsWorkerSaga)
}

