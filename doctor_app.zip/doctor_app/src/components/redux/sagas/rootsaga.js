import {all} from 'redux-saga/effects'
import { fetchApptsWatcherSaga } from "./myAppointmentsSaga";


/**
 * root saga to combine sagas
 */
export default function* rootSaga() {
    yield all([
    (fetchApptsWatcherSaga())
    ])
   
  }