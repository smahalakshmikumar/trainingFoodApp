
//log in/out actions
export const LOG_IN = "LOG_IN";
export const LOG_OUT = "LOG_OUT";

//Doctors list actions
export const FETCH_SUCCESS_DOCTORSLIST = "FETCH_SUCCESS_RESTAURANTLIST";
export const FETCH_FAILURE_DOCTORSLIST = "FETCH_FAILURE_RESTAURANTLIST";
export const FETCH_SUCCESS_DOCTOR = "FETCH_SUCCESS_DOCTOR";

//appointment actions
export const ADD_TO_APPT = "ADD_TO_APPT";
export const REMOVE_FROM_APPT = "REMOVE_FROM_APPT";
export const CLEAR_APPT = "CLEAR_APPT";


//saga appt actions
export const FETCH_SAGA_SUCCESS_APPTS = "FETCH_SAGA_SUCCESS_APPTS";
export const FETCH_SUCCESS_APPT = "FETCH_SUCCESS_APPT";



//Loader
export const SET_LOADER="SET_LOADER";


