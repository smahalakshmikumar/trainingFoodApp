import axios from "axios";
import * as api from "../../api/api"
import {
    FETCH_SUCCESS_DOCTORSLIST,
    FETCH_FAILURE_DOCTORSLIST, SET_LOADER,FETCH_SUCCESS_DOCTOR
} from "./actionTypes";

/**
 * Fetching list of Doctors
 * @returns dispatch fetch success list of doctors
 */
export const fetchDoctorsList = () => {
  return (async(dispatch, state) => {
    dispatch(setLoader(true));
    try{
      let response = await api.getData("doctor/");
      dispatch(fetchSuccess(response.data));
      dispatch(setLoader(false))
    
    }
    catch(err){
      dispatch(fetchFailure(err));
      dispatch(setLoader(false))
    }
  });
};

/**
 * Fetching selected Doctor
 * @returns dispatch fetch success list of doctors
 */
export const fetchSelectedDoctor = (paramID) => {
  return (async(dispatch, state) => {
    dispatch(setLoader(true));
    try{
      let response = await api.getData(`doctor/${paramID}?_embed=doctordetails`);
      dispatch(fetchSelectedSuccess(response.data));
      dispatch(setLoader(false))
    
    }
    catch(err){
      dispatch(fetchFailure(err));
      dispatch(setLoader(false))
    }
  });
};

/**
 * updated selected Doctor details-->edit slots booked
 * @returns updated selected Doctor details
 */
//  export const putDocDetails = (paramID,order) => {
//   return (async(dispatch, state) => {
//     dispatch(setLoader(true));
//     try{
//       let response = await api.patchData(`doctor/${paramID}?_embed=doctordetails`,order);
//       dispatch(fetchSelectedSuccess(response.data));
//       dispatch(setLoader(false));
//     }
//     catch(err){
//       dispatch(fetchFailure(err));
//       dispatch(setLoader(false))
//     }
//   });
// };

/**
 * success response
 * @param {array} data -takes response data
 * @param {object} options -shows options 
 * @returns type:FETCH_SUCCESS_DOCTORSLIST,data
 */
export const fetchSuccess = (data, options = {}) => {
  return { type: FETCH_SUCCESS_DOCTORSLIST, payload: data};
};

/**
 * success response
 * @param {object} data -takes response data
 * @param {object} options -shows options 
 * @returns type:FETCH_SUCCESS_DOCTOR,data
 */
 export const fetchSelectedSuccess = (data, options = {}) => {
  return { type: FETCH_SUCCESS_DOCTOR, payload: data};
};


/**
 * fetch failure to return error 
 * @param {error} displays error 
 * @returns type fetch failure,payload data
 */
export const fetchFailure = (err) => {
  return { type: FETCH_FAILURE_DOCTORSLIST, payload: err.message };
};


/**
 * set loader action
 * @param {boolean} isLoading -whether to display progress
 * @returns type,payload
 */
export const setLoader = (isLoading) => {
  return { type: SET_LOADER, payload: isLoading };
};


