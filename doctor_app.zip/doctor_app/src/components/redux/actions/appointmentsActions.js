import * as api from "../../api/api"
import {
    
    FETCH_SUCCESS_APPT,SET_LOADER,FETCH_SAGA_SUCCESS_APPTS
} from "./actionTypes";


/**
 * post order action
 * @param {array} order- to post particular order
 * @returns post order
 */
 export const postAppt = (order) => {
  return (async(dispatch, state) => {
    try{
      let response= await api.postData("userappointments", order)
      console.log(response.data)
      //dispatch(addToAppt(response.data));
    }
    catch(err){
    
    }
});
};

/**
 * remove item
 * @param {number} id- remove item
 * @returns delete apppt
 */
 export const deleteAppt = (deleteid,id) => {
  return (async(dispatch, state) => {
    try{
      let response=await api.deleteData(`userappointments/${deleteid}`)
      console.log(response.data)
      dispatch({
        type: FETCH_SAGA_SUCCESS_APPTS,
        payload: id
      })
    }
    catch(err){
    }
});
};

  
// /**
//  * fetching appts
//  * @param { array } appt-fetching appointments
//  * @returns fetching appts
//  */
 export const fetchAppt= (apptItem) => {
  return {
    type: FETCH_SUCCESS_APPT,
    payload: apptItem,
  };
};
  
/**
 * set loader action
 * @param {boolean} isLoading -whether to display progress
 * @returns type,payload
 */
export const setLoader = (isLoading) => {
  return { type: SET_LOADER, payload: isLoading };
};