import React from "react";
import NavigationBar from "../../UI/NavigationBar";
import { Button } from "react-bootstrap";


/**
 * MyProfileChild component presentation comp
 * @param {array}appointments- list of appointments
 * @returns order component
*/
const MyProfileChild = ({ appointments,addSlot }) => {
  /**
   * @returns triggers parent addSlot
   */
  const addSlotTrigger=()=>{
    addSlot();
  }
  return (
    <>
      <NavigationBar />
      <div class="card" style={{ width: "40rem", margin: "20px" }}>
        <div class="card-header">
          <h4>My Profile</h4>
        </div>
        {appointments?.map((data) => (
          <div style={{ margin: "20px" }}>
            <h5 style={{color:"blue"}} >Booked by Patient: {data.patientName}</h5>
            <strong>Time:{data.apptDetails.timeSlot}</strong>
            <p>Location: {data.apptDetails.location}</p>
            
          </div>
        ))}
        <div class="card-footer"><Button onClick={addSlotTrigger}>Add Slot</Button></div>

      </div>
    </>
  );
}
export default MyProfileChild;