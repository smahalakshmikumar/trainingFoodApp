
import MyProfileChild from './MyProfileChild';
import React, { useEffect, useState } from "react";
import * as api from "../api/api"
import { useSelector, useDispatch } from 'react-redux';
import { useHistory } from "react-router-dom";

/**
 * 
 * @returns MyProfile component
 */
const MyProfile = () => {
    let dispatch = useDispatch();
    let history = useHistory();
    const [appointements, setAppointements] = useState();
    const userLoggedin = useSelector((state) => state?.users?.usersList);
    const { id, role, email } = userLoggedin[0];

    /**
     * @returns go to add slot page
     */
    const addSlot=()=>{
        history.push("/addSlot");
    }
    /**
     *fetching the appointments data
     * @returns axios response
     */
    useEffect(async () => {
        //fetching the appointments details for admin/normal user
        try 
        {

            let response = await api.getData("userappointments")
            console.log("filter", response.data.filter((item) => item.docMailId == email))
            //filtering appointments for particular doctor based on mail id
            let appointmentData = response.data.filter((item) => item.docMailId == email)
            setAppointements(appointmentData);


        } catch (error) {
            console.log(error.message);
        }
    }, []);

    return (
        <MyProfileChild
            appointments={appointements} addSlot={addSlot} />

    );
}

export default MyProfile;


