import React from "react";
import { Nav, Navbar } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { Logout } from "../components/redux/actions/loginAction";
import Button from '@material-ui/core/Button';
import { useHistory } from 'react-router-dom';

/**
 *  NavigationBar component
 * @returns NavigationBar
 */
export const NavigationBar = () => {
  let dispatch = useDispatch();
  let history = useHistory();
  //getting logged in user state from store
  const state = useSelector((state) => state?.users?.usersList);
  const { firstName, email, role } = state[0];
  
  /**
   * logout function clicked
   * @returns dispatch logout and pushing to next page
   */
  const logoutClicked = () => {
    dispatch(Logout());
    history.push("/")
  };
  return (
    <Navbar
      bg="primary"
      expand="lg"
      sticky="top"
      top="0"
      style={{
        marginLeft: "-20px",
        marginRight: "-20px",
      }}
      position="fixed"
    >
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Brand href="/">Medical Buddy</Navbar.Brand>
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-auto">
          {firstName ? (
          
            <Nav.Item>
              {role=="admin"?<Button variant="contained"> Dr.{firstName},</Button>:
                            <Button variant="contained"> {firstName},</Button>
                          }
            </Nav.Item>
          ) : null}
          <Nav.Item>
            <Button  id="docListPath"  onClick={() => history.push("/doctorsList")} >Available Doctors</Button>
          </Nav.Item>
          <Nav.Item>
            <Button id="myApptPath" onClick={() => history.push("/myAppointments")} >My Appointments</Button>
          </Nav.Item>
          {role=="admin"?(
            <>
             <Nav.Item>
             <Button id="myProfilePath" onClick={() => history.push("/myProfile")} >My Profile</Button>
            </Nav.Item>
            <Nav.Item>
             <Button id="addSlotPath" onClick={() => history.push("/addSlot")} >Add Slot</Button>
           </Nav.Item>
            </>
          ):null}
          <Nav.Item>
            <Button  onClick={logoutClicked} >Log Out</Button>
          </Nav.Item>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  );
};
export default NavigationBar;
