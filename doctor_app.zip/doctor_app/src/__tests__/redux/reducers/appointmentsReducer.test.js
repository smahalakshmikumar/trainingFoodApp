import appointmentsReducer from "../../../components/redux/reducers/appointmentsReducer"
import {FETCH_SUCCESS_APPT} from "../../../components/redux/actions/actionTypes";
 
describe("appointmentsReducer",()=>{

    describe("when appointmentsReducer and action{type:FETCH_SUCCESS_APPT}",()=>{
        describe("AND when state is []",()=>{
            it("should return updated state",()=>{
            let item={id:1,time:"1PM-1.30PM"}
            
            let state = { 
                isLoading: false,
                confirmedAppts:{}
            }
          let action={type:FETCH_SUCCESS_APPT,payload:item}
          let result= appointmentsReducer(state,action);
           expect(result).toStrictEqual({confirmedAppts:item,
             isLoading: false});
        });
    })
        
})
 
describe("when appointmentsReducer and action{type:DEFAULT}",()=>{
    describe("AND when state is []",()=>{
        it("should return updated state",()=>{
      let item={id:1,time:"1PM-1.30PM"}    
      let state = { 
          isLoading: false,
          confirmedAppts:{}
      }
      let action={type:"DEFAULT_ACTION"}
      let result= appointmentsReducer(state,action);
       expect(result).toStrictEqual(state);
    });
})

})

})





   
