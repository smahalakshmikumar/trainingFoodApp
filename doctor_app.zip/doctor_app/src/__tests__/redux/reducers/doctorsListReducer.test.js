import doctorsListReducer from "../../../components/redux/reducers/doctorsListReducer"
import {FETCH_SUCCESS_DOCTORSLIST,
    FETCH_FAILURE_DOCTORSLIST, SET_LOADER,FETCH_SUCCESS_DOCTOR} from "../../../components/redux/actions/actionTypes";
 
describe("doctorsListReducer",()=>{

    describe("when doctorsListReducer and action{type:FETCH_SUCCESS_DOCTOR}",()=>{
        describe("AND when state is []",()=>{
            it("should return updated state",()=>{
            let item1={id:1,time:"1PM-1.30PM"}
            let item2={id:2,time:"1PM-1.30PM"}
           let state = { doctorsList: [],selectedDoc:[],
                isLoading: false, error: "" };
          let action={type:FETCH_SUCCESS_DOCTOR,payload:[item1,item2]}
          let result= doctorsListReducer(state,action);
           expect(result).toStrictEqual({selectedDoc:[item1,item2],
             isLoading: false,doctorsList:[],error:""});
        });
        
    })

   
        
})
 

describe("when doctorsListReducer and action{type:FETCH_SUCCESS_DOCTORSLIST}",()=>{
    describe("AND when state is []",()=>{
        it("should return updated state",()=>{
            let item1={id:1,time:"1PM-1.30PM"}
            let item2={id:2,time:"1PM-1.30PM"}
           let state = { doctorsList: [],selectedDoc:[],
                isLoading: false, error: "" };
        let action={type:FETCH_SUCCESS_DOCTORSLIST,payload:[item1,item2]}
        let result= doctorsListReducer(state,action);
        expect(result).toStrictEqual({doctorsList:[item1,item2],
          isLoading: false,selectedDoc:[],error:""});
    });
})

})

describe("when doctorsListReducer and action{type:DEFAULT}",()=>{
    describe("AND when state is []",()=>{
        it("should return updated state",()=>{
      let item={id:1,time:"1PM-1.30PM"}    
      let state = { doctorsList: [],selectedDoc:[],
        isLoading: false, error: "" };
      let action={type:"DEFAULT_ACTION"}
      let result= doctorsListReducer(state,action);
       expect(result).toStrictEqual(state);
    });
})

})

describe("when doctorsListReducer and action{type:FETCH_FAILURE_DOCTORSLIST}",()=>{
    describe("AND when state is []",()=>{
        it("should return updated state",()=>{
        let error="error occurred"
        let state = { doctorsList: [],selectedDoc:[],
            isLoading: false, error: "" };
      let action={type:FETCH_FAILURE_DOCTORSLIST,payload:error}
      let result= doctorsListReducer(state,action);
       expect(result).toStrictEqual({doctorsList: [],selectedDoc:[],
        isLoading: false,  error: error });
    });
})

})

describe("when doctorsListReducer and action{type:SET_LOADER}",()=>{
    describe("AND when state is []",()=>{
        it("should return updated state",()=>{
        let isLoading=true
        let state = { doctorsList: [],selectedDoc:[],
            isLoading: false, error: "" };
      let action={type:SET_LOADER,payload:isLoading}
      let result= doctorsListReducer(state,action);
       expect(result).toStrictEqual({doctorsList: [],selectedDoc:[],
        isLoading: isLoading,  error: "" });
    });
})

})

})





   
