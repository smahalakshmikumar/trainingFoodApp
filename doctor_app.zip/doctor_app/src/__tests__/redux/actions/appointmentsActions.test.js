import {postAppt,deleteAppt,setLoader,fetchAppt} from "../../../components/redux/actions/appointmentsActions";
import {FETCH_SUCCESS_APPT,SET_LOADER,FETCH_SAGA_SUCCESS_APPTS
} from "../../../components/redux/actions/actionTypes"


describe("appointments actions",()=>{

    describe("fetchAppt",()=>{
        it("should return fetchAppt action obj",()=>{
            let dataItem= [{id:1},{id:2}];
            let result = fetchAppt(dataItem);
            expect(result).toStrictEqual({type: FETCH_SUCCESS_APPT,
                payload: dataItem})
        })
    })

    describe("setLoader",()=>{
        it("should return setLoader action obj",()=>{
            let isLoading=true;
            let result = setLoader(isLoading);
            expect(result).toStrictEqual({type: SET_LOADER,
                payload: isLoading})
        })
    })

   
})