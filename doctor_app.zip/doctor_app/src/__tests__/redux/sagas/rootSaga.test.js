import rootSaga from "../../../components/redux/sagas/rootSaga";
import {all} from 'redux-saga/effects'
import {fetchApptsWatcherSaga} from "../../../components/redux/sagas/myAppointmentsSaga"
describe("Given root saga",()=>{
    it("should return combined sagas",()=>{
        let rootSagas= rootSaga();
        expect(rootSagas.next().value).toEqual(all([
            (fetchApptsWatcherSaga()) 
            ]))
    })
})