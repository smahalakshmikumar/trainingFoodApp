import { fetchApptsWatcherSaga, fetchApptsWorkerSaga } from "../../../components/redux/sagas/myAppointmentsSaga"
import {takeEvery,takeLatest } from 'redux-saga/effects'
import {FETCH_SAGA_SUCCESS_APPTS} from "../../../components/redux/actions/actionTypes"
import { runSaga } from "redux-saga"
import { createMockTask } from '@redux-saga/testing-utils';
import {fetchAppt,setLoader} from "../../../components/redux/actions/appointmentsActions"
import * as api from "../../../components/api/api";



describe("Given myAppointments saga", () => {
    describe("Given fetchApptsWatcherSaga", () => {
        it("should return fetchApptsWatcherSaga saga", () => {
            let workerSaga = takeLatest(FETCH_SAGA_SUCCESS_APPTS, fetchApptsWorkerSaga);
            let orderWatcher = fetchApptsWatcherSaga();
            expect(orderWatcher.next().value).toStrictEqual(workerSaga);
            })
    })

    describe("Given fetchApptsWorkerSaga", () => {
        describe("AND when success", () => {
            it("should return correct value", async () => {
                let response = { data: { id: 1} }
                let getDataSpy = jest.spyOn(api, 'getData').
                mockImplementation(() => Promise.resolve(response))
                let dispatched = [];
                await runSaga({
                    dispatch: (action) => dispatched.push(action)
                }, fetchApptsWorkerSaga, { id: 1 });

                expect(getDataSpy).toHaveBeenCalled();
                expect(getDataSpy).toHaveBeenCalledTimes(1);

                expect(dispatched.length).toBe(3);
                expect(dispatched[0]).toStrictEqual(setLoader(true))
                expect(dispatched[1]).toStrictEqual(fetchAppt(response.data))
                expect(dispatched[2]).toStrictEqual(setLoader(false))

            })

        })

    })


})