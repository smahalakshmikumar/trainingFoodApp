import React from "react";
import "@testing-library/jest-dom/extend-expect";
import { render, fireEvent} from "@testing-library/react";
import LoginForm from "../../../components/login/LoginForm"
import { Provider } from "react-redux";
import { BrowserRouter  } from "react-router-dom";
import { createStore } from "redux";
import rootReducer from "../../../components/redux/reducers"


describe("Given Login comp", () => {
    let mockAppstore;
    let wrapper;
    let dispatch = jest.fn();
    let mockHistory={push:jest.fn(),listen:jest.fn(),location:{}}
    beforeEach(() => {
        //redux
        mockAppstore = createStore(rootReducer, {
            doctors: {
                doctorsList: [{"id":1,"docName":"Karthika devi"}],
            selectedDoc:[[{"id":1,"docName":"Karthika devi"}]],
            isLoading: false, error: ""},
            appts:{confirmedAppts:{}},
            users: { usersList: [{ "id": 1, "firstName": "Maha", "role": "admin" }],
             isLoading: false }
           
        })
       
    });
    it("should show validation on blur", async () => {
           const { getByLabelText, getByTestId } = render(
            <BrowserRouter history={mockHistory}>
            <Provider store={mockAppstore}>
             <LoginForm/>
            </Provider> 
         </BrowserRouter>
          );
    //   const input = getByLabelText("email");
     // fireEvent.blur(input);
      //await(() => {
          expect(getByTestId("emailField")).toBeInTheDocument();
        // expect(getByTestId("emailError")).not.toBe(null);
        // expect(getByTestId("emailError")).toHaveTextContent("Email is required");

     // });
    });

});
