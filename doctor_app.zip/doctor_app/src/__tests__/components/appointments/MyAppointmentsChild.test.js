import { Button } from "react-bootstrap";
import MyAppointmentsChild from "../../../components/appointements/MyAppointmentsChild";
import { Provider } from "react-redux";
import { createStore } from "redux";
import rootReducer from "../../../components/redux/reducers";
import { mount, shallow } from "enzyme";
import { Router } from "react-router-dom";


describe("Given MyAppointmentsChild comp", () => {
    let wrapper;
    let appts ;
    let mockAppstore;
    let cancelAppt = jest.fn();
    let mockHistory = { push: jest.fn(), listen: jest.fn(), location: {} }

    beforeEach(() => {
        //redux
        mockAppstore = createStore(rootReducer, {
            doctors: {
                doctorsList: [{ "id": 1, "docName": "Karthika devi" }],
                selectedDoc: [[{ "id": 1, "docName": "Karthika devi" }]],
                isLoading: false, error: ""
            },
            appts: {
                confirmedAppts: {
                    "userappointments": [{
                        "docMailId": "karthika@gmail.com",
                        "id": "1",
                        "patientName": "Shantha Kumar",
                        "userId": " 7",
                        "apptDetails":{
                         "date": "15.06.2021",
                        "docName": "Karthika Thiyagarajan",
                        "location": "Chennai",
                        "slotId": 19,
                        "timeSlot": "11-11.30AM"
                    }
                        
                    }]
                }
            },
            users: {
                usersList: [{ "id": 1, "firstName": "Maha", "role": "admin" }],
                isLoading: false
            }

        })
        appts = mockAppstore?.getState().appts.confirmedAppts.userappointments
        wrapper = mount(
            <Router history={mockHistory}>
                <Provider store={mockAppstore}>
                    <MyAppointmentsChild cancelAppt={cancelAppt} appointments={appts} />
                </Provider>
            </Router>)

    });

    it("should render cart comp", () => {
        expect(wrapper).toHaveLength(1);
    })


    describe('when "cancel button" is clicked', () => {

        it("should dispatch cancel action", () => {
            const cancelClickButton = wrapper.find(Button).find('#cancelClick').
                find('button');
                cancelClickButton.simulate('click');
            expect(cancelAppt).toHaveBeenCalled();
        })
    })






})