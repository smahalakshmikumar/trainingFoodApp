import TestRenderer from "react-test-renderer"
import { create, act } from 'react-test-renderer';
import { Button } from "react-bootstrap";
import DoctorsListChild from "../../../../components/doctors/doctorsList/DoctorsListChild";
import { Provider } from "react-redux";
import { createStore } from "redux";
import rootReducer from "../../../../components/redux/reducers"
import { mount, shallow } from "enzyme";
import { Router } from "react-router-dom";


describe("Given DoctorsList Child comp", () => {
    let wrapper;
    let mockAppstore;
    let dispatch = jest.fn();
    let viewMore = jest.fn();
    let mockHistory={push:jest.fn(),listen:jest.fn(),location:{}}

    beforeEach(() => {
        //redux
        mockAppstore = createStore(rootReducer, {
            doctors: {
                doctorsList: [{"id":1,"docName":"Karthika devi"}],
            selectedDoc:[[{"id":1,"docName":"Karthika devi"}]],
            isLoading: false, error: ""},
            appts:{confirmedAppts:{}},
            users: { usersList: [{ "id": 1, "firstName": "Maha", "role": "admin" }],
             isLoading: false }
           
        })
       let data= mockAppstore.getState().doctors?.doctorsList;
       let loading=mockAppstore.getState().users?.isLoading;
        wrapper = mount(
            <Router history={mockHistory}>
        <Provider store={mockAppstore}>
            <DoctorsListChild doctorsList={data} viewMore={viewMore} isLoading={loading}/>
        </Provider>
        </Router>
        )
    });

    it("should render DoctorsList comp", () => {
        expect(wrapper).toHaveLength(1);
        
    })

    describe('when "View more" is clicked', () => {

        it("should dispatch view more action", () => {
            const viewMorebutton = wrapper.find(Button).find('#viewMore').
                find('button');
                viewMorebutton.simulate('click');
            expect(viewMore).toHaveBeenCalled();
            expect(viewMore).toHaveBeenCalledWith(1);
        })
    })

  

   

})