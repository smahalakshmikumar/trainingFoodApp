import React from "react";
import "@testing-library/jest-dom/extend-expect";
import { render, fireEvent} from "@testing-library/react";
import AddSlot from "../../../components/addSlot/AddSlot";
import { Provider } from "react-redux";
import { Router } from "react-router-dom";
import { createStore } from "redux";
import rootReducer from "../../../components/redux/reducers"


describe("Given CartParent comp", () => {
    let mockAppstore;
    let wrapper;
    let dispatch = jest.fn();
    let mockHistory={push:jest.fn(),listen:jest.fn(),location:{}}
    beforeEach(() => {
        //redux
        mockAppstore = createStore(rootReducer, {
            doctors: {
                doctorsList: [{id:1,docName:"Karthika devi"}],
            selectedDoc:[[{id:1,docName:"Karthika devi"}]],
            isLoading: false, error: ""},
            appts:{confirmedAppts:{}},
            users: { usersList: [{ id: 1, firstName: "Maha", role: "admin" }],
             isLoading: false }
           
        })
       
    });
    it("should show validation on blur", async () => {
           const { getByLabelText, getByTestId } = render(
            <Router history={mockHistory}>
            <Provider store={mockAppstore}>
             <AddSlot/>
            </Provider> 
         </Router>
          );
      await(() => {
        expect(getByTestId("locationField")).toBeInTheDocument();
    
 });
    });

});
