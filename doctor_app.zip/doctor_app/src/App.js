import "./App.css";
import React, { Suspense } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

//implementing Lazy loading in components
const DoctorsList = React.lazy(() =>
  import("./components/doctors/doctorsList/DoctorsList")
);
const SelectedDoctor= React.lazy(()=>import("./components/doctors/selectedDoc/SelecterDoctor"
));
const Register= React.lazy(()=>import("./components/register/Register"
));
const LoginForm=React.lazy(()=>import("./components/login/LoginForm"))
const MyAppointments=React.lazy(()=>import("./components/appointements/MyAppointments"))
const MyProfile=React.lazy(()=>import("./components/myProfile/MyProfile"))
const AddSlot=React.lazy(()=>import("./components/addSlot/AddSlot"));


function App() {
  return (
    <div className="App">
    <React.Fragment>
      <Router>
        <Switch>
            <Suspense fallback={<div>Loading...</div>}>
              <Route component={LoginForm} path="/" exact={true}/>
              <Route component={Register} path="/registration"/>
              <Route component={DoctorsList} path="/doctorsList"/>
              <Route component={SelectedDoctor} path="/doctor/:id" />
              <Route component={MyAppointments} path="/myAppointments" />
              <Route component={MyProfile} path="/myProfile" />
              <Route component={AddSlot} path="/addSlot" />

            </Suspense>
        </Switch>
      </Router>
    </React.Fragment>
  </div>
  );
}

export default App;
