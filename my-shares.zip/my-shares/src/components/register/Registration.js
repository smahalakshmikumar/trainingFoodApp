import React from 'react';


/**
 * Register page
 * @returns //Register component
 */

 const Registration = () => {
}
export default React.memo(Registration);