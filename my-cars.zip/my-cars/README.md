Login page nav bar-->Makes ViewCart Logout
display list of makes
display view models in makes--> which displays list of models for each make--> choose one

displays vehicles with chosen model and make:
List of available vehicles--> choose one which will be displayed in my cart page(add delete feature)
