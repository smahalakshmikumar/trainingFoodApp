import React, { useState } from "react";
import { CAR_IMAGE } from "../../constants";
import Header from "../../UI/header/Header";
import CardComponent from "../../UI/cardComponent/CardComponent";
import Modal from "../../UI/modal/modal";

/**
 *  vehicle component  presentation comp
 * @returns MyVehiclesChild
 * @param {array} datasource- data to populate selected vehicle
 * @param {boolean} isDataPresent- to check if data is there or not
 * @param {object} make- make of car
 * @param {object} model-model of car */

const MyVehiclesChild = ({ dataSource, addCar, make, model }) => {
  //triggers parent callback
  const callAddCar = (data) => {
    addCar(data);
  };
  return (
    <div class="container-fluid">
      <Header />
      <h1>
        List of Vehicles in {make}-{model}
      </h1>
      <div class="main">
        {dataSource?.map((data) => (
          <CardComponent title={data.make} imageSrc={CAR_IMAGE}>
            <div className="vehicle-details">
              <p>
                enginePowerPS:<strong>{data.enginePowerPS}</strong>
              </p>
              <p>
                enginePowerKW:<strong>{data.enginePowerKW}</strong>
              </p>
              <p>
                fuelType:<strong>{data.fuelType}</strong>
              </p>
              <p>
                bodyType:<strong>{data.bodyType}</strong>
              </p>
              <p>
                bodyType:<strong>{data.engineCapacity}</strong>
              </p>

              <button
                class="view-button"
                type="button"
                onClick={() => callAddCar(data)}
              >
                Add Vehicle
              </button>
            </div>
          </CardComponent>
        ))}
      </div>
    </div>
  );
};
export default React.memo(MyVehiclesChild);
