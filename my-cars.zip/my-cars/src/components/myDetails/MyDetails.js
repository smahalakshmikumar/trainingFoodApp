import React, { useEffect, useState } from "react";
import MyDetailsChild from "./MyDetails.child";
import { getData } from "../../api/api";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { RemoveFromMyVehicles } from "../redux/actions/myDetailsAction";

/**
 *  MyDetails
 * @returns MyDetails page component
 */
const MyDetails = (props) => {
  const [dataSource, setData] = useState([]);
  const [isDataPresent, setIsDataPresent] = useState(false);

  let dispatch = useDispatch();
  let history = useHistory();
  //getting  vehicles list,setloader from store
  let { myDetailsList, isLoading } = useSelector((state) => state?.myDetails);

  /*
  @returns dispatching action data to add vehicles action
  */
  const deleteCar = (id) => {
    dispatch(RemoveFromMyVehicles(id));
  };

  return (
    <div class="container-fluid">
      <MyDetailsChild
        dataSource={myDetailsList}
        deleteCar={deleteCar}
        isDataPresent={isDataPresent}
      />
    </div>
  );
};
export default React.memo(MyDetails);
