import React, { useState } from "react";
import { CAR_IMAGE } from "../../constants";
import Header from "../../UI/header/Header";
import CardComponent from "../../UI/cardComponent/CardComponent";

/**
 *  MyDetails  presentation comp
 * @returns MyDetailsChild
 * @param {array} datasource- data to populate selected vehicle
 */
const MyDetailsChild = ({ dataSource, deleteCar }) => {
  //triggers parent callback
  const callDeleteCar = (id) => {
    deleteCar(id);
  };
  return (
    <div class="container-fluid">
      <Header />
      <h1>My Car Details</h1>
      <div class="main">
        {dataSource.length > 0 ? (
          <>
            {dataSource.map((data, index) => (
              <CardComponent title={data.make} imageSrc={CAR_IMAGE}>
                <div className="vehicle-details">
                  <p>
                    enginePowerPS:<strong>{data.enginePowerPS}</strong>
                  </p>
                  <p>
                    enginePowerKW:<strong>{data.enginePowerKW}</strong>
                  </p>
                  <p>
                    fuelType:<strong>{data.fuelType}</strong>
                  </p>
                  <p>
                    bodyType:<strong>{data.bodyType}</strong>
                  </p>
                  <p>
                    bodyType:<strong>{data.engineCapacity}</strong>
                  </p>

                  <button
                    class="view-button"
                    type="button"
                    onClick={() => callDeleteCar(index)}
                  >
                    Delete Vehicle
                  </button>
                </div>
              </CardComponent>
            ))}
          </>
        ) : (
          <h1>No data Found</h1>
        )}
      </div>
    </div>
  );
};
export default React.memo(MyDetailsChild);
