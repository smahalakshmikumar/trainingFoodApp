import React, { useState } from "react";
import { ReactComponent as CloseMenu } from "../../assets/x.svg";
import { ReactComponent as MenuIcon } from "../../assets/menu.svg";
import "./Header.css";

const Header = () => {
  const [click, setClick] = useState(false);
  const handleClick = () => setClick(!click);
  const closeMobileMenu = () => setClick(false);
  // var navbar = document.getElementsByClassName("header");
  //   var sticky = navbar.offsetTop;
  //   const stickyFunc = () => {
  //     if (window.pageYOffset >= sticky) {
  //       navbar.classList.add("sticky");
  //     } else {
  //       navbar.classList.remove("sticky");
  //     }
  //   };
  //   window.onscroll = function () {
  //     stickyFunc();
  //   };

  return (
    <div className="header">
      <div className="logo-nav">
        <div className="logo-container">
          <h1>My Cars</h1>
        </div>
        <ul className={click ? "nav-options active" : "nav-options"}>
          {/* mob */}
          <li className="option mobile-option" onClick={closeMobileMenu}>
            <a href="/makes">Car Makes</a>
          </li>
          <li className="option mobile-option" onClick={closeMobileMenu}>
            <a href="/details">My Details</a>
          </li>
          <li className="option mobile-option" onClick={closeMobileMenu}>
            <a href="/makes" className="sign-up">
              SIGN-OUT
            </a>
          </li>
        </ul>
      </div>
      <ul className="signin-up" style={{ marginLeft: "800px" }}>
        {/* desk */}
        <li className="sign-in" onClick={closeMobileMenu}>
          <a href="/makes">Car Makes</a>
        </li>
        <li className="sign-in" onClick={closeMobileMenu}>
          <a href="/details">My Details</a>
        </li>
        <li onClick={closeMobileMenu}>
          <a href="/makes" className="signup-btn">
            SIGN-OUT
          </a>
        </li>
      </ul>
      <div className="mobile-menu" onClick={handleClick}>
        {click ? (
          <CloseMenu className="menu-icon" />
        ) : (
          <MenuIcon className="menu-icon" />
        )}
      </div>
    </div>
  );
};

export default Header;
