export const CAR_IMAGE =
  "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTVAQLUtvoP5ktHJz2baVtzktJ35b_nZ0Vj1ARyt7a_nlcI1FLc_gZHFsZ7DOvu1l5W2Io&usqp=CAU";
