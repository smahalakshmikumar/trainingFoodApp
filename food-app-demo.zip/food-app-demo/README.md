//my shares
user should be able to see list of shares
--> show share name
--> show market price
-->view more

show my wallet option
-->display price in wallet

--> on click of buy
--> take to new screen and display more details about that particular share
-->about company
-->show graph-->todays low and high
-->Buy --> quantity of shares, price of that quantity, wallet balance
-->sell --> same options

after buy click--> take to new screen and display the details of how much quanity bought and share name total price
provide sell option here also

