//wishlist constants
export const REMOVE_FROM_WISHLIST="Remove from wishlist";
export const ADD_ITEMS_WISHlIST="Add items to wishlist";
export const CLEAR_WISHLIST="Clear Wishlist"

//Restaurant details constants
export const GO_WISHLIST="Go to wishlist";
export const RECOMMENDED="Recommended:";
export const COST_OF_FOOD="cost for two:";
export const ADDED_TO_CART="Added to cart";
export const RESTAURANT_RATING="Restaurant Rating :";
export const SEE_MORE="See More";

//Restaurant list constants
export const REMOVE_RESTAURANT="Remove Restaurant";
export const VIEW_MORE="View more";
export const SAGA_RES="Display Restaurants by saga";
export const ADD_TO_RESTAURANT="Add Restaurant";


//orders constants
export const TOTAL="Total Price";
export const FOOD_ITEM="Food Item:";
export const MY_ORDERS="My Orders";










